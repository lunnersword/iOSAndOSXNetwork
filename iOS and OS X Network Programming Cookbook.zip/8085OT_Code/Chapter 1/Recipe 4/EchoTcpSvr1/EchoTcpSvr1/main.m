//
//  main.m
//  EchoTcpSvr1
//
//  Created by Jon Hoffman on 11/24/12.
//  Copyright (c) 2012 Jon Hoffman. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BSDSocketServer.h"

#import <sys/socket.h>
#import <arpa/inet.h>
#import <netinet/in.h>
#import <pthread.h>

#define MAXLINE 4096



int main(int argc, const char * argv[])
{
    
    @autoreleasepool {
        
        // insert code here...
        NSLog(@"Hello, World!");

        BSDSocketServer *bsdServ = [[BSDSocketServer alloc] initOnPort:2004];
        if (bsdServ.errorCode == NOERROR) {
            [bsdServ echoServerListenWithDescriptor:bsdServ.listenfd];
            
        } else {
            NSLog(@"%@",[NSString stringWithFormat:@"Error code %d recieved.  Server was not started", bsdServ.errorCode]);
        }
        
    }
    return 0;
}




