//
//  main.m
//  EchoTcpSvr1IOS
//
//  Created by Jon Hoffman on 12/16/12.
//  Copyright (c) 2012 Jon Hoffman. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
