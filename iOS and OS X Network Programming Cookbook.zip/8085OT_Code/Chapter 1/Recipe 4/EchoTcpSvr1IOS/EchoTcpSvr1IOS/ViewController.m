//
//  ViewController.m
//  EchoTcpSvr1IOS
//
//  Created by Jon Hoffman on 12/16/12.
//  Copyright (c) 2012 Jon Hoffman. All rights reserved.
//

#import "ViewController.h"
#import "BSDSocketServer.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    NSLog(@"Hello, World!");
    [echoText setText:@"Hello World"];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(newTextRecieved:) name:@"posttext" object:nil ] ;
    [NSThread detachNewThreadSelector:@selector(startSvr) toTarget:self withObject:nil];
    //  [self startSvr];
    
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



-(void)startSvr {
    
    BSDSocketServer *bsdServ = [[BSDSocketServer alloc] initOnPort:2004];
    if (bsdServ.errorCode == NOERROR) {
        [bsdServ echoServerListenWithDescriptor:bsdServ.listenfd];
        
    } else {
        [self setLabelText:[NSString stringWithFormat:@"Error code %d recieved.  Server was not started", bsdServ.errorCode]];
    }
}



-(void)errorRecv:(NSString *) msg {
    UIAlertView *av = [[UIAlertView alloc] initWithTitle:@"Error" message:msg delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [av show];
    [av release];
}

-(void)newTextRecieved:(NSNotification *)notification {
    [self performSelectorOnMainThread:@selector(setLabelText:) withObject:[notification object] waitUntilDone:NO ];
}

-(void)setLabelText:(NSString *)str {
    NSLog(@"Setting:  %@",str);
    
    [echoText setText:str];
}



@end
