//
//  ViewController.h
//  AddrInfo-iOS
//
//  Created by Jon Hoffman on 1/10/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NetworkAddressInformation.h"

@interface ViewController : UIViewController {
    NetworkAddressInformation *nai;
    int count;
    
    IBOutlet UILabel *addressNumberLabel, *versionLabel, *interfaceLabel, *addressLabel, *networkLabel, *gatewayLabel;
}

@end
