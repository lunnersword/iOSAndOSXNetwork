//
//  ViewController.m
//  AddrInfo-iOS
//
//  Created by Jon Hoffman on 1/10/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import "ViewController.h"


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    nai = [[NetworkAddressInformation alloc] init];
    count = 0;
    UISwipeGestureRecognizer *swipeGestureRight = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(didSwipe:)];
    swipeGestureRight.direction = UISwipeGestureRecognizerDirectionRight;
    [self.view addGestureRecognizer:swipeGestureRight];
    
    UISwipeGestureRecognizer *swipeGestureLeft = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(didSwipe:)];
    swipeGestureLeft.direction = UISwipeGestureRecognizerDirectionLeft;
    [self.view addGestureRecognizer:swipeGestureLeft];
    
    [self showAddressInfo];
    
}

-(void)didSwipe:(UISwipeGestureRecognizer*)sender {
    switch (sender.direction) {
        case UISwipeGestureRecognizerDirectionLeft:
            count ++;
            [self showAddressInfo];
            break;
        case UISwipeGestureRecognizerDirectionRight:
            count --;
            [self showAddressInfo];
            break;
        default:
            break;
    }
}

-(void)showAddressInfo {

    if (nai != nil && [nai.networkAddresses count] > 0) {
        if (count < 0)
            count = [nai.networkAddresses count] -1;
        if (count > ([nai.networkAddresses count] -1))
            count = 0;
        
        NetworkAddressStore *ns = [nai.networkAddresses objectAtIndex:count];
        addressNumberLabel.text = [NSString stringWithFormat:@"Address %d of %d", count+1, [nai.networkAddresses count]];
        versionLabel.text = [ns getAddressVersionString];
        interfaceLabel.text = ns.interface;
        addressLabel.text = ns.address;
        networkLabel.text = ns.netmask;
        gatewayLabel.text = ns.gateway;
    }
}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
