//
//  main.m
//  AddrInfo
//
//  Created by Jon Hoffman on 12/4/12.
//  Copyright (c) 2012 Jon Hoffman. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NetworkAddressInformation.h"


int main(int argc, const char * argv[])
{

    @autoreleasepool {
        NetworkAddressInformation *ni = [[NetworkAddressInformation alloc] init];
        
        for (NetworkAddressStore *ns in ni.networkAddresses) {
            NSLog(@"%@:", ns.interface);
            NSLog(@"     Version:  %@", [ns getAddressVersionString]);
            NSLog(@"     Address:  %@", ns.address);
            NSLog(@"     Netmask:  %@", ns.netmask);
            NSLog(@"     Gateway:  %@", ns.gateway);
        }
        
    }
    return 0;
}

