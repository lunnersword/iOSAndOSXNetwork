//
//  main.m
//  ByteOrder
//
//  Created by Jon Hoffman on 11/23/12.
//  Copyright (c) 2012 Jon Hoffman. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ByteOrder.h"


int main(int argc, const char * argv[])
{
    
    @autoreleasepool {
        
        ByteOrder *bo = [[ByteOrder alloc] init];
        int byteOrder = bo.byteOrder;
        
        switch (byteOrder) {
            case ENDIAN_BIG:
                NSLog(@"Big-Endian");
                break;
            case ENDIAN_LITTLE:
                NSLog(@"Little-Endian");
                break;
            case ENDIAN_UNKNOWN:
                NSLog(@"Unknown Endian");
                break;
                
            default:
                break;
        }
        
    }
    return 0;
}

