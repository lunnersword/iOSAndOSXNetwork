//
//  ViewController.m
//  ByteOrderiOS
//
//  Created by Jon Hoffman on 3/30/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import "ViewController.h"
#import "ByteOrder.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    ByteOrder *bo = [[ByteOrder alloc] init];
    EndianType byteOrder = bo.byteOrder;
    
    switch (byteOrder) {
        case ENDIAN_BIG:
            byteOrderLabel.text = @"Big-Endian";
            break;
        case ENDIAN_LITTLE:
            byteOrderLabel.text = @"Little-Endian";
            break;
        case ENDIAN_UNKNOWN:
            byteOrderLabel.text = @"Unknown Endian";
            break;
            
        default:
            break;
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
