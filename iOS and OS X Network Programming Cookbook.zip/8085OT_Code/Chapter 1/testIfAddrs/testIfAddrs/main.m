//
//  main.m
//  testIfAddrs
//
//  Created by Jon Hoffman on 5/15/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import <Foundation/Foundation.h>

#import <sys/types.h>
#import <sys/socket.h>
#import <netdb.h>
#import <arpa/inet.h>
#import <ifaddrs.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        struct ifaddrs *interfaces = NULL;
        struct ifaddrs *temp_addr = NULL;
        int success = 0;
        
        success = getifaddrs(&interfaces);
        if (success == 0) {
            temp_addr = interfaces;
            for (temp_addr = interfaces; temp_addr != NULL; temp_addr = temp_addr->ifa_next) {
                int ipversion;
                NSLog(@"************************");
                if(temp_addr->ifa_addr->sa_family == AF_INET) {
                    NSLog(@"IPv4");
                    ipversion = AF_INET;
                } else if(temp_addr->ifa_addr->sa_family == AF_INET6) {
                    NSLog(@"IPv6");
                    ipversion = AF_INET6;
                } else {
                    NSLog(@"Unknown IP version");
                    ipversion = 0;
                }
                char naddr[INET6_ADDRSTRLEN];
                char nmask[INET6_ADDRSTRLEN];
                char ngate[INET6_ADDRSTRLEN];
                NSLog(@"Name:  %@",[NSString stringWithUTF8String:temp_addr->ifa_name]);
                inet_ntop(ipversion,&((struct sockaddr_in *)temp_addr->ifa_addr)->sin_addr,naddr,INET_ADDRSTRLEN);
                NSLog(@"Address:  %@",[NSString stringWithUTF8String:naddr]);
                if ((struct sockaddr_in6 *)temp_addr->ifa_netmask != NULL) {
                    inet_ntop(ipversion,&((struct sockaddr_in *)temp_addr->ifa_netmask)->sin_addr,nmask,INET_ADDRSTRLEN);
                    NSLog(@"Netmask:  %@", [NSString stringWithUTF8String:nmask]);
                }
                if ((struct sockaddr_in6 *)temp_addr->ifa_dstaddr != NULL) {
                    inet_ntop(ipversion,&((struct sockaddr_in *)temp_addr->ifa_dstaddr)->sin_addr,ngate,INET_ADDRSTRLEN);
                    NSLog(@"Gateway:  ", [NSString stringWithUTF8String:ngate]);
                }
            }
        }
        
    }
    return 0;
}

