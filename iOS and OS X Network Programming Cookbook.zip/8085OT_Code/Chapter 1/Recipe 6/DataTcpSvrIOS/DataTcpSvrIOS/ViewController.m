//
//  ViewController.m
//  DataTcpSvrIOS
//
//  Created by Jon Hoffman on 1/5/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//
#import "ViewController.h"
#import "BSDSocketServer.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [NSThread detachNewThreadSelector:@selector(startSvr) toTarget:self withObject:nil];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)startSvr {
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(newDataRecieved:) name:@"postdata" object:nil ] ;
    
    BSDSocketServer *bsdServ = [[BSDSocketServer alloc] initOnPort:2006];
    if (bsdServ.errorcde == NOERRROR) {
        [bsdServ dataServerListenWithDescriptor:bsdServ.listenfd];
        
    } else {
        NSLog(@"%@",[NSString stringWithFormat:@"Error code %d recieved.  Server was not started", bsdServ.errorcde]);
    }

}

-(void)newDataRecieved:(NSNotification *)notification {
    NSData *data = notification.object;
    imageView.image = [UIImage imageWithData:data];
}

@end
