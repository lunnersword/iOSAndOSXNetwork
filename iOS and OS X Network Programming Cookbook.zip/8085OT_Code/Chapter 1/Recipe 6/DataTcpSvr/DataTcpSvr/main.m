//
//  main.m
//  DataTcpSvr
//
//  Created by Jon Hoffman on 4/13/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BSDSocketServer.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        // insert code here...
        NSLog(@"Hello, World!");
        BSDSocketServer *bsdServ = [[BSDSocketServer alloc] initOnPort:2006];
        if (bsdServ.errorCode == NOERROR) {
            [bsdServ dataServerListenWithDescriptor:bsdServ.listenfd];
            
        } else {
            NSLog(@"%@",[NSString stringWithFormat:@"Error code %d recieved.  Server was not started", bsdServ.errorCode]);
        }

        
    }
    return 0;
}

