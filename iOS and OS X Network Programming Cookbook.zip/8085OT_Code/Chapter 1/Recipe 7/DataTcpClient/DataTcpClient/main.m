//
//  main.m
//  DataTcpClient
//
//  Created by Jon Hoffman on 1/5/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BSDSocketClient.h"



int main(int argc, const char * argv[])
{
    
    @autoreleasepool {
        
        // insert code here...
        NSLog(@"Hello, World!");
        BSDSocketClient *bsdCli = [[BSDSocketClient alloc] initWithAddress:@"127.0.0.1" andPort:2006];
        if (bsdCli.errorCode == NOERRROR) {
            NSData *data = [NSData dataWithContentsOfFile:@"/Users/hoffmanjon/Documents/GreenGuyLarge2.png"];
         //   NSData *data = [NSData dataWithContentsOfFile:@"/Users/hoffmanjon/3circles.png"];
            [bsdCli sendData:data toSocket:bsdCli.sockfd];
        } else {
            NSLog(@"%@",[NSString stringWithFormat:@"Error code %d recieved. ", bsdCli.errorCode]);
        }
    }

    return 0;
}


