//
//  main.m
//  EchoTcpClient2
//
//  Created by Jon Hoffman on 4/12/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BSDSocketClient.h"


int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        // insert code here...
        NSLog(@"Hello, World!");
        
        char sendline[MAXLINE];
        
        BSDSocketClient *bsdCli = [[BSDSocketClient alloc] initWithAddress:@"127.0.0.1" andPort:2005];
        if (bsdCli.errorCode == NOERRROR) {
            while (fgets(sendline, MAXLINE,stdin)) {
                [bsdCli writtenToSocket:bsdCli.sockfd withChar:[NSString stringWithUTF8String:sendline]];
                
                NSString *recv = [bsdCli recvFromSocket:bsdCli.sockfd withMaxChar:MAXLINE];
                NSLog(@"Echoed back:  %@",recv);
            }
            
        } else {
            NSLog(@"%@",[NSString stringWithFormat:@"Error code %d recieved.  Server was not started", bsdCli.errorCode]);
        }
        
    }
    return 0;
}

