//
//  ViewController.h
//  EchoTcpClientIOS
//
//  Created by Jon Hoffman on 4/12/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController {
    IBOutlet UILabel *textRecvLabel;
    IBOutlet UITextField *textField;
}

@end
