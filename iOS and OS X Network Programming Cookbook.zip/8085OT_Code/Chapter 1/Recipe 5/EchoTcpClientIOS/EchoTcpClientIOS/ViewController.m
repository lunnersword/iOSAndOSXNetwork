//
//  ViewController.m
//  EchoTcpClientIOS
//
//  Created by Jon Hoffman on 4/12/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import "ViewController.h"
#import "BSDSocketClient.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)sendPressed:(id)sender {
    NSString *str = textField.text;
    BSDSocketClient *bsdCli = [[BSDSocketClient alloc] initWithAddress:@"127.0.0.1" andPort:2004];
    if (bsdCli.errorCode == NOERRROR) {
        [bsdCli writtenToSocket:bsdCli.sockfd withChar:str];
        
        NSString *recv = [bsdCli recvFromSocket:bsdCli.sockfd withMaxChar:MAXLINE];
        textRecvLabel.text = recv;
        textField.text = @"";
        
    } else {
        NSLog(@"%@",[NSString stringWithFormat:@"Error code %d recieved.  Server was not started", bsdCli.errorCode]);
    }
}

@end
