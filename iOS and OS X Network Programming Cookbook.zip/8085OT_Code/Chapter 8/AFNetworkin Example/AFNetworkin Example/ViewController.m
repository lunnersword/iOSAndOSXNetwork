//
//  ViewController.m
//  AFNetworkin Example
//
//  Created by Jon Hoffman on 11/14/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import "ViewController.h"
#import "ITunesClient.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    NSString *type=@"album";
    NSString *term=@"jimmy+buffett";
    [[ITunesClient sharedClient] searchType:type withTerm:term
                            completion:^(NSDictionary *results, NSError *error) {
                                if (results) {
                                    NSLog(@"%@", results);
                                    NSArray *resultsArray = [results objectForKey:@"results"];

                                    for (NSDictionary *res in resultsArray) {
                                        NSLog(@"--------Artist Name:  %@", [res objectForKey:@"artistName"] );
                                        NSLog(@"        Album:  %@", [res objectForKey:@"collectionCensoredName"]);
                                    }
                                } else {
                                        NSLog(@"ERROR: %@", error);
                                                                     }
                                }];

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
