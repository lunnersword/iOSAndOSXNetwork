//
//  ITunesClient.m
//  AFNetworkin Example
//
//  Created by Jon Hoffman on 11/14/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import "ITunesClient.h"

@implementation ITunesClient

+ (ITunesClient *)sharedClient {
    static ITunesClient *sharedClient = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        NSURL *baseURL = [NSURL URLWithString:@"https://itunes.apple.com/"];
        
        NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
        
        sharedClient = [[ITunesClient alloc] initWithBaseURL:baseURL sessionConfiguration:config];
        sharedClient.responseSerializer = [AFJSONResponseSerializer serializer];
    });
    
    return sharedClient;
}

- (NSURLSessionDataTask *)searchType:(NSString *)type withTerm:(NSString *)term completion:( void (^)(NSDictionary *results,NSError *error) )completion {
    
    NSDictionary *params = [[NSDictionary alloc] initWithObjectsAndKeys:type,@"entity",term,@"term", nil];
    
    NSURLSessionDataTask *task = [self GET:@"/search" parameters:params
                        success:^(NSURLSessionDataTask *task, id responseObject) {
                            
                            NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *)task.response;
                            if (httpResponse.statusCode == 200) {
                                dispatch_async(dispatch_get_main_queue(), ^{
                                    completion(responseObject, nil);
                                });
                            } else {
                                dispatch_async(dispatch_get_main_queue(), ^{
                                    completion(nil, nil);
                                });
                            }
                                       
                        } failure:^(NSURLSessionDataTask *task, NSError *error) {
                            dispatch_async(dispatch_get_main_queue(), ^{
                                completion(nil, error);
                            });
                        }];
    return task;
}

@end
