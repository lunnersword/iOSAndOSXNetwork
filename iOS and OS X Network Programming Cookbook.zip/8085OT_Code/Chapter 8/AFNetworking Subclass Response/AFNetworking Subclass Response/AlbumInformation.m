//
//  AlbumInformation.m
//  AFNetworking Subclass Response
//
//  Created by Jon Hoffman on 11/14/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import "AlbumInformation.h"

@implementation AlbumInformation

-(instancetype)initWithDictionary:(NSDictionary *)dict {
    if (self = [super init])
    {
        self.artistName = [dict objectForKey:@"artistName"];
        self.albumName = [dict objectForKey:@"collectionCensoredName"];
        self.imgUrl = [dict objectForKey:@"artworkUrl100"];
        self.trackCount = [dict objectForKey:@"trackCount"];
    }
    return self;
}

@end
