//
//  AlbumInformation.h
//  AFNetworking Subclass Response
//
//  Created by Jon Hoffman on 11/14/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AlbumInformation : NSObject

@property (strong, nonatomic) NSString *artistName, *albumName, *imgUrl, *trackCount;

-(instancetype)initWithDictionary:(NSDictionary *)dict;

@end
