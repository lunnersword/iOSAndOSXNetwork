//
//  ViewController.m
//  AFNetworking Subclass Response
//
//  Created by Jon Hoffman on 11/14/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import "ViewController.h"
#import "ITunesClient.h"
#import "AlbumInformation.h"
#import "UIImageView+AFNetworking.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    AFNetworkReachabilityManager *reachability = [AFNetworkReachabilityManager sharedManager];
    [reachability setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        switch (status) {
            case AFNetworkReachabilityStatusReachableViaWWAN:
                NSLog(@"----Connection WWAN");
                break;
            case AFNetworkReachabilityStatusReachableViaWiFi:
                NSLog(@"----WIFI");
                break;
            case AFNetworkReachabilityStatusNotReachable:
                NSLog(@"----Not Reachable");
                break;
            default:
                break;
        }
    }];
    
    
	NSString *type=@"album";
    NSString *term=@"jimmy+buffett";
    ITunesClient *itunesClient = [ITunesClient sharedClient];
    [itunesClient searchType:type withTerm:term
                                 completion:^(NSArray *results, NSError *error) {
                                     if (results) {
                                         self.albums = results;
                                         for(AlbumInformation *album in results) {
                                             NSLog(@"--------Artist Name:  %@", album.artistName);
                                             NSLog(@"        Album:  %@", album.albumName);
                                             NSLog(@"        img URL:  %@", album.imgUrl);
                                             NSLog(@"        Track Count:  %@", album.trackCount);
                                         }
                                         [self.tableView reloadData];
                                     } else {
                                         NSLog(@"ERROR: %@", error);
                                     }
                                 }];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.albums count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 75.0; //returns floating point which will be used for a cell row height at specified row index
}


- (UITableViewCell *)tableView:(UITableView *)lTableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellID = @"Cell";
    UITableViewCell *cell = [lTableView dequeueReusableCellWithIdentifier:cellID];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellID];
    }
    AlbumInformation *album = [self.albums objectAtIndex:indexPath.row];
    
    cell.textLabel.numberOfLines = 3;
    cell.textLabel.font = [UIFont systemFontOfSize:14];
    cell.textLabel.text = album.albumName;
    
    cell.detailTextLabel.font = [UIFont boldSystemFontOfSize:16];
    cell.detailTextLabel.text = [NSString stringWithFormat:@"Tracks:  %@",album.trackCount];
    
    NSURL *url = [[NSURL alloc] initWithString:album.imgUrl];
    [cell.imageView setImageWithURL:url placeholderImage:[UIImage imageNamed:@"loading"]];
    
 /*   CALayer *layer = [cell.imageView layer];
    [layer setMasksToBounds:YES];
    [layer setCornerRadius:10]; */
    
    return cell;
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
