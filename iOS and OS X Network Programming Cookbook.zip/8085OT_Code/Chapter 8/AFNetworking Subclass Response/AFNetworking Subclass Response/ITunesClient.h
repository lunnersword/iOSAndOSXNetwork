//
//  ITunesClient.h
//  AFNetworkin Example
//
//  Created by Jon Hoffman on 11/14/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import "AFHTTPSessionManager.h"

@interface ITunesClient : AFHTTPSessionManager

+ (ITunesClient *)sharedClient;
- (NSURLSessionDataTask *)searchType:(NSString *)type withTerm:(NSString *)term completion:( void (^)(NSArray *results, NSError *error) )completion;

@end
