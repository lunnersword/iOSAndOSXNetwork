//
//  ITunesResponseSerializer.h
//  AFNetworking Subclass Response
//
//  Created by Jon Hoffman on 11/14/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import "AFURLResponseSerialization.h"
#import "AlbumInformation.h"

@interface ITunesResponseSerializer :AFJSONResponseSerializer

@end
