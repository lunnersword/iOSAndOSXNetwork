//
//  ITunesResponseSerializer.m
//  AFNetworking Subclass Response
//
//  Created by Jon Hoffman on 11/14/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import "ITunesResponseSerializer.h"


@implementation ITunesResponseSerializer

-(id)responseObjectForResponse:(NSURLResponse *)response data:(NSData *)data error:(NSError *__autoreleasing *)error
{
    NSMutableArray *retArray = [[NSMutableArray alloc] init];
    NSDictionary *json = [super responseObjectForResponse:response data:data error:error];
    NSArray *results = [json objectForKey:@"results"];
    for (NSDictionary *result in results) {
        [retArray addObject:[[AlbumInformation alloc] initWithDictionary:result]];
    }
    return retArray;
}

@end
