//
//  ViewController.h
//  AFNetworking Download
//
//  Created by Jon Hoffman on 11/16/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIProgressView+AFNetworking.h"

@interface ViewController : UIViewController

@property (strong, nonatomic) IBOutlet UIProgressView *progressView;

@end
