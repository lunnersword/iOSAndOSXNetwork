//
//  AppDelegate.h
//  AFNetworking Download
//
//  Created by Jon Hoffman on 11/16/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
