//
//  main.m
//  libnet_getIPAddress
//
//  Created by Jon Hoffman on 6/30/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <libnet.h>


int main(int argc, const char * argv[])
{
    
    @autoreleasepool {

        libnet_t *lnet;
        char errbuf[LIBNET_ERRBUF_SIZE];
        u_int32_t addr;
        struct libnet_in6_addr addr6;
        char ipv6addr[64];
        struct libnet_ether_addr *mac_addr;
        
        lnet = libnet_init(LIBNET_RAW4, NULL, errbuf);
        if ( lnet == NULL ) {
            NSLog(@"Error with libnet_init():  %s", errbuf);
            exit(EXIT_FAILURE);
        }
        
        //IPv4
        addr = libnet_get_ipaddr4(lnet);
        if ( addr != -1 )
            NSLog(@"IPv4 address: %s\n", libnet_addr2name4(addr,LIBNET_DONT_RESOLVE));
        else {
            NSLog(@"Error retrieving IP address: %s",libnet_geterror(lnet));
            exit(EXIT_FAILURE);
        }
        //IPv6
        addr6 = libnet_get_ipaddr6(lnet);
        libnet_addr2name6_r(addr6, LIBNET_DONT_RESOLVE, ipv6addr, sizeof(ipv6addr));
        NSLog(@"%s",ipv6addr);
        
        //MAC
        mac_addr = libnet_get_hwaddr(lnet);
        if ( mac_addr != NULL )
            NSLog(@"MAC address: %02X:%02X:%02X:%02X:%02X:%02X\n",mac_addr->ether_addr_octet[0],mac_addr->ether_addr_octet[1],mac_addr->ether_addr_octet[2],mac_addr->ether_addr_octet[3],mac_addr->ether_addr_octet[4],mac_addr->ether_addr_octet[5]);
        else
            NSLog(@"Couldn't get my MAC address: %s\n",libnet_geterror(lnet));
        
        libnet_destroy(lnet);
        
    }
    return 0;
}

