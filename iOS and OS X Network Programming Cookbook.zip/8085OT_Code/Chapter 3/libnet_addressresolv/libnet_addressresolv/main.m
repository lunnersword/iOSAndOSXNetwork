//
//  main.m
//  libnet_addressresolv
//
//  Created by Jon Hoffman on 7/1/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <libnet.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        libnet_t *lnet;
        char errbuf[LIBNET_ERRBUF_SIZE];
        u_int32_t addr;
        struct libnet_in6_addr addr6;
        char ipv6addr[64];
        
        char addr_str[] = "www.packtpub.com";
        
        lnet = libnet_init(LIBNET_RAW4, NULL, errbuf);
        if ( lnet == NULL ) {
            NSLog(@"libnet_init() failed: %s", errbuf);
            exit(EXIT_FAILURE);
        }
        //IPv4
        addr = libnet_name2addr4(lnet, addr_str, LIBNET_RESOLVE);
        NSLog(@"%s",libnet_addr2name4(addr, LIBNET_DONT_RESOLVE));
        //IPv6
        addr6 = libnet_name2addr6(lnet, addr_str, LIBNET_RESOLVE);
        libnet_addr2name6_r(addr6, LIBNET_DONT_RESOLVE, ipv6addr, sizeof(ipv6addr));
        NSLog(@"%s",ipv6addr);
        
        libnet_destroy(lnet);
    }
    return 0;
}

