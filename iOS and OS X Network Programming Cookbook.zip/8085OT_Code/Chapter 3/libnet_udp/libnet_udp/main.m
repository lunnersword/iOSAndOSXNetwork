//
//  main.m
//  libnet_udp
//
//  Created by Jon Hoffman on 7/2/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import <Foundation/Foundation.h>
#import </usr/local/include/libnet.h>

#define TARGETIP "10.0.0.21"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        libnet_t *lnet;
        u_int32_t target, source;
        u_int16_t id,seq;
        char payload[] = "Hello from libnet";
        char errbuf[LIBNET_ERRBUF_SIZE];
        
        lnet = libnet_init(LIBNET_RAW4, NULL, errbuf);
        if ( lnet == NULL ) {
            NSLog(@"Error with libnet_init():  %s", errbuf);
            exit(EXIT_FAILURE);
        }

        target = libnet_name2addr4(lnet, TARGETIP, LIBNET_DONT_RESOLVE);
        
        source  = libnet_get_ipaddr4(lnet);
        if ( source == -1 ) {
            NSLog(@"Error retrieving IP address: %s",libnet_geterror(lnet));
            libnet_destroy(lnet);
            exit(EXIT_FAILURE);
        }
        
        /* Generating a random id */
        libnet_seed_prand (lnet);
        id = (u_int16_t)libnet_get_prand(LIBNET_PR16);
        
        /* Building UDP header */
        seq = 1;
        
        if (libnet_build_udp(
                             libnet_get_prand (LIBNET_PRu16),                
                             101,
                             LIBNET_UDP_H+ sizeof(payload),
                             0,                   
                             (u_int8_t*)payload,
                             sizeof(payload),
                             lnet,                
                             0) == -1)
        {
            NSLog(@"Error building UDP header: %s\n",libnet_geterror(lnet));
            libnet_destroy(lnet);
            exit(EXIT_FAILURE);
        }
        
        /* Building IP header */
        if( libnet_build_ipv4(LIBNET_UDP_H + LIBNET_IPV4_H + sizeof(payload),
                              0,
                              id,
                              0,
                              64,
                              IPPROTO_UDP,
                              0,
                              source,
                              target,
                              NULL,
                              0,
                              lnet,
                              0) == -1)
        {
            NSLog(@"Error building IP header: %s\n",libnet_geterror(lnet));
            libnet_destroy(lnet);
            exit(EXIT_FAILURE);
        }
        
        /* Writing packet */
        int bytes_written = libnet_write(lnet);
        if ( bytes_written != -1 )
            printf("%d bytes written.\n", bytes_written);
        else
            NSLog(@"Error writing packet: %s\n",libnet_geterror(lnet));
        
        libnet_destroy(lnet);

        
    }
    return 0;
}

