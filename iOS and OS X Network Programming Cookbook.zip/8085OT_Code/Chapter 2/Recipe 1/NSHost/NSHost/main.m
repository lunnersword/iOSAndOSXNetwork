//
//  main.m
//  NSHost
//
//  Created by Jon Hoffman on 4/25/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        // insert code here...
        NSLog(@"Hello, World!");
        NSHost* myhost =[NSHost currentHost];
        if (myhost)
        {
            NSArray *addrs = [myhost addresses];
            
            for (NSString *addr in addrs) {
                NSLog(@"%@", addr );
            }
        }

        
    }
    return 0;
}

