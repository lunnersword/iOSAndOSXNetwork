//
//  NetworkDetect.m
//
//  Created by Jon Hoffman on 4/26/11.
//  Copyright 2011 
//

#import "NetworkDetect.h"
#import <SystemConfiguration/SystemConfiguration.h>
#import <net/if.h>

@implementation NetworkDetect

+(int)networkConnectionType
{    
    const char *hostname = "www.packtpub.com";
    SCNetworkReachabilityRef reachabilityRef = SCNetworkReachabilityCreateWithName(NULL, hostname);;    
    SCNetworkReachabilityFlags flags;
    SCNetworkReachabilityGetFlags(reachabilityRef, &flags);
    
    BOOL isReachable = ((flags & kSCNetworkFlagsReachable) != 0);
    BOOL needsConnection = ((flags & kSCNetworkFlagsConnectionRequired) != 0);
    NSLog(@"%d  %d", isReachable, needsConnection);
    if(isReachable && !needsConnection) // connection is available 
    {
        // determine what type of connection is available
        BOOL isCellularConnection = ((flags & kSCNetworkReachabilityFlagsIsWWAN) != 0);

        if(isCellularConnection) 
            return MOBILE3GNETWORK; // cellular connection available
        else
            return WIFINETWORK; // wifi connection available
    }
    return NONETWORK; // no connection at all
}


@end
