//
//  ViewController.m
//  NetworkConnectionTypeIOS
//
//  Created by Jon Hoffman on 4/24/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import "ViewController.h"
#import "NetworkDetect.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];

    int cType = [NetworkDetect networkConnectionType];
    
    NSString *connectString = @"Unknown Connection";
    
    switch (cType) {
        case NONETWORK:
            connectString = @"No Network Connection";
            break;
        case WIFINETWORK:
            connectString = @"WIFI Connection";
            break;
        case MOBILE3GNETWORK:
            connectString = @"Celluar Connection";
            break;
            
        default:
            break;
    }
    label.text = connectString;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
