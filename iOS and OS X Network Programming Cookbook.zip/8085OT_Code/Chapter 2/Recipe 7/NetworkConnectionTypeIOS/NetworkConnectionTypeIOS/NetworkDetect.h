//
//  NetworkDetect.h
//
//  Created by Jon Hoffman on 4/26/11.
//  Copyright 2011 
//
//  Detects what type of network the iPad is currently connected too.  An example of using this class
//  is in the WebServiceLogin Class.
//
//   NetworkDetect *nd = [[NetworkDetect alloc]init];
//   int networkType = [nd networkConnectionType];
//   NSLog(@"Network type %d", networkType);

//   if (networkType == nd.WIFINETWORK || networkType == nd.MOBILE3GNETWORK) {
//      NSLog(@"Do Something that requires a network connection");
//   }
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, NetworkTypes) {
    NONETWORK,
    MOBILE3GNETWORK,
    WIFINETWORK
};

@interface NetworkDetect : NSObject 

+(int)networkConnectionType;

@end
