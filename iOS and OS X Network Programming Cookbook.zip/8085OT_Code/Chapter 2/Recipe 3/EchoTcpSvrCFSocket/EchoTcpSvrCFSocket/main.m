//
//  main.m
//  EchoTcpSvrCFSocket
//
//  Created by Jon Hoffman on 4/21/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CFSocketServer.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        // insert code here...
        NSLog(@"Hello, World!");
        
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^{
            CFSocketServer *cf = [[CFSocketServer alloc] initOnPort:2007];
            if (cf.errorCode != NOERROR) {
                NSString *str = [NSString stringWithFormat:@"Error starting server.  Error code: %d",cf.errorCode];
                NSLog(@"%@",str);
            }
        });
        
        
        while (1) {
            //get on with our applicaiton, the run loop will handle the incoming connection
        }
        NSLog(@"bye");
        
    }
    return 0;
}

