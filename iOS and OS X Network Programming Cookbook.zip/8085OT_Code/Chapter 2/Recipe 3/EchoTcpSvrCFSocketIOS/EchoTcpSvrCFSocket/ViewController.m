//
//  ViewController.m
//  EchoTcpSvrCFSocket
//
//  Created by Jon Hoffman on 1/6/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import "ViewController.h"
#import "CFSocketServer.h"


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(newTextRecieved:) name:@"posttext" object:nil ] ;

    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^{
        [self threadStart];
    });
}

-(void)threadStart {
    CFSocketServer *cf = [[CFSocketServer alloc] initOnPort:2009];
    if (cf.errorCode != NOERROR) {
        NSString *str = [NSString stringWithFormat:@"Error starting server.  Error code: %d",cf.errorCode];
        [self performSelectorOnMainThread:@selector(setLabelText:) withObject:str waitUntilDone:NO ];
    }
    NSLog(@"Returned");
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)newTextRecieved:(NSNotification *)notification {
    [self performSelectorOnMainThread:@selector(setLabelText:) withObject:[notification object] waitUntilDone:NO ];
}

-(void)setLabelText:(NSString *)str {
    [echoText setText:str];
}


@end
