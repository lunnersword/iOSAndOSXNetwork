//
//  ViewController.h
//  EchoTcpSvrCFSocket
//
//  Created by Jon Hoffman on 1/6/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController {
    IBOutlet UILabel *echoText;
    CFSocketRef sRef;
    
}

@end
