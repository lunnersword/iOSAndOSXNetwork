//
//  ViewController.m
//  EchoTcpClientCFSocketIOS
//
//  Created by Jon Hoffman on 4/19/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import "ViewController.h"
#import "CFSocketClient.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)sendPressed:(id)sender {
    NSString *str = textField.text;
    CFSocketClient *cf = [[CFSocketClient alloc] initWithAddress:@"127.0.0.1" andPort:2004];
    if (cf.errorCode == NOERROR) {
        NSString *recv = [cf writtenToSocket:cf.sockfd withChar:str];
        NSLog(@"%@",recv);
        textRecvLabel.text = recv;
        textField.text = @"";
        
    } else {
        NSLog(@"%@",[NSString stringWithFormat:@"Error code %d recieved.  Could not connect.", cf.errorCode]);
    }
}

@end
