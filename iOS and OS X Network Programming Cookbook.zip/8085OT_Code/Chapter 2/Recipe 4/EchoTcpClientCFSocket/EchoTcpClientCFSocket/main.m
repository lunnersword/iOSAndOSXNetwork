//
//  main.m
//  EchoTcpClientCFSocket
//
//  Created by Jon Hoffman on 4/19/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CFSocketClient.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        CFSocketClient *cf = [[CFSocketClient alloc] initWithAddress:@"127.0.0.1" andPort:2007];
        char sendline[MAXLINE];
        if (cf.errorCode == NOERROR) {
            NSLog(@"---Enter Text");
            while (fgets(sendline, MAXLINE,stdin)) {
                [cf writtenToSocket:cf.sockfd withChar:[NSString stringWithUTF8String:sendline]];
            }  
        
        } else {
            NSLog(@"Connection Error");
        }
    }
    return 0;
}

