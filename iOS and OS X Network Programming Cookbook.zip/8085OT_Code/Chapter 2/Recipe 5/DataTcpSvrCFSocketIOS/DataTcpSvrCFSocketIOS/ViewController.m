//
//  ViewController.m
//  DataTcpSvrCFSocketIOS
//
//  Created by Jon Hoffman on 4/21/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import "ViewController.h"
#import "CFSocketServer.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    newImage = YES;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(newImageRecieved:) name:NOTIFICATIONIMAGE object:nil ] ;
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^{
        CFSocketServer *cf = [[CFSocketServer alloc] initOnPort:2010 andServerType:SERVERTYPEIMAGE];
        if (cf.errorCode != NOERROR) {
            NSString *str = [NSString stringWithFormat:@"Error starting server.  Error code: %d",cf.errorCode];
            NSLog(@"%@",str);
        }
    });
}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)newImageRecieved:(NSNotification *)notification {
    [self performSelectorOnMainThread:@selector(setImage:) withObject:[notification object] waitUntilDone:NO ];
}

-(void)setImage:(NSData *)imgData {
    NSLog(@"HERE:  %d", [imgData length]);
    if (newImage) {
        img = [[NSMutableData alloc] init];
        newImage = NO;
    }
    [img appendData:imgData];
    if ([imgData length] == 0) {
        imageView.image = [UIImage imageWithData:img];
        newImage = YES;
    }
}


@end
