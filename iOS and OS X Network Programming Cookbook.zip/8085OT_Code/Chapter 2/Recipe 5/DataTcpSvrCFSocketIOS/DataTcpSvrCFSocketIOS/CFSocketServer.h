//
//  CFSocketServer.h
//  EchoTcpSvrCFSocket
//
//  Created by Jon Hoffman on 4/19/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, CFNetworkServerErrorCode) {
    NOERROR,
    SOCKETERROR,
    BINDERROR,
    LISTENERROR,
    CFSOCKETCREATEERROR,
    ACCEPTINGERROR
};

typedef  NS_ENUM(NSUInteger, CFNetworkServerType) {
    SERVERTYPEECHO,
    SERVERTYPEIMAGE
};


#define NOTIFICATIONTEXT @"posttext"
#define NOTIFICATIONIMAGE @"postimage"

@interface CFSocketServer : NSObject

@property (nonatomic) int errorCode;
@property (nonatomic) CFSocketRef sRef;

-(instancetype)initOnPort:(int)port andServerType:(int)sType;

@end
