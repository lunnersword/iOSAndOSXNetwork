//
//  CFSocketServer.m
//  EchoTcpSvrCFSocket
//
//  Created by Jon Hoffman on 4/19/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import "CFSocketServer.h"
#import <CoreFoundation/CFSocket.h>
#include <sys/socket.h>
#include <netinet/in.h>
#import <arpa/inet.h>

#define LISTENQ 1024

@implementation CFSocketServer


-(instancetype)initOnPort:(int)port andServerType:(int)sType {
    struct sockaddr_in servaddr;
	CFRunLoopSourceRef source;
    const CFSocketContext context = {0, NULL, NULL, NULL, NULL};
	self.errorCode = NOERROR;
    int listenfd;
	if ((listenfd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP))<0) {
        self.self.errorCode = SOCKETERROR;
    } else {
        memset(&servaddr, 0, sizeof(servaddr));
        servaddr.sin_family = AF_INET;
        servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
        servaddr.sin_port = htons(port);
        if (bind(listenfd, (struct sockaddr *)&servaddr, sizeof(servaddr)) <0) {
            self.self.errorCode = BINDERROR;
        } else {
            if (listen(listenfd, LISTENQ) <0) {
                self.errorCode = LISTENERROR;
            } else {
                if (sType == SERVERTYPEECHO)
                    self.sRef = CFSocketCreateWithNative(NULL, listenfd, kCFSocketAcceptCallBack,
                                                acceptConnectionEcho, &context);
                else if (sType == SERVERTYPEIMAGE)
                    self.sRef = CFSocketCreateWithNative(NULL, listenfd, kCFSocketAcceptCallBack,
                                                    acceptConnectionData, &context);
                else
                    self.sRef = NULL;
                if (self.sRef == NULL) {
                    self.errorCode = CFSOCKETCREATEERROR;
                }else {
                    NSLog(@"Starting");
                    source = CFSocketCreateRunLoopSource(NULL, self.sRef, 0);
                    CFRunLoopAddSource(CFRunLoopGetCurrent(), source, kCFRunLoopDefaultMode);
                    CFRelease(source);
                    CFRunLoopRun();
                }
            }
        }
        
    }
    return self;
}

//For Echo server
void receiveDataEcho(CFSocketRef sRef, CFSocketCallBackType cType,CFDataRef address, const void *data, void *info)
{
	CFDataRef df = (CFDataRef) data;
    long len = CFDataGetLength(df);
    if(len <= 0) return;
    
    UInt8 buf[len];
    CFRange range = CFRangeMake(0,len);
    
    CFDataGetBytes(df, range, buf);
    buf[len]='\0';
    NSString *str = [[NSString alloc] initWithData:(__bridge NSData*)data
                                          encoding:NSASCIIStringEncoding];
    [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFICATIONTEXT object:str];
    CFSocketSendData(sRef, address, df, 0);	// Echo back
}

void acceptConnectionEcho(CFSocketRef sRef, CFSocketCallBackType cType, CFDataRef address, const void *data, void *info)
{

	CFSocketNativeHandle csock = *(CFSocketNativeHandle *)data;
	CFSocketRef sn;
	CFRunLoopSourceRef source;
    
    const CFSocketContext context = {0, NULL, NULL, NULL, NULL};
    
	sn = CFSocketCreateWithNative(NULL, csock, kCFSocketDataCallBack, receiveDataEcho, &context);
    
    source = CFSocketCreateRunLoopSource(NULL, sn, 0);
    CFRunLoopAddSource(CFRunLoopGetCurrent(), source, kCFRunLoopDefaultMode);
    CFRelease(source);
    CFRelease(sn);
}


//For Data server
void receiveDataData(CFSocketRef sRef, CFSocketCallBackType cType,CFDataRef address, const void *data, void *info)
{
    NSLog(@"Receiving data");
	CFDataRef df = (CFDataRef) data;
    NSData *imgData = (__bridge NSData *)df;
    struct sockaddr_in addr = *(struct sockaddr_in*)CFDataGetBytePtr(address);
    char buf[INET6_ADDRSTRLEN];
    NSString *connStr = [NSString stringWithFormat:@"Connection from %s, port %d", inet_ntop(AF_INET, &addr.sin_addr,buf, sizeof(buf)),ntohs(addr.sin_port)];
    NSLog(@"%@", connStr);
    
    [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFICATIONIMAGE object:imgData];
}

void acceptConnectionData(CFSocketRef sRef, CFSocketCallBackType cType, CFDataRef address, const void *data, void *info)
{
    NSLog(@"Accepting");
	CFSocketNativeHandle csock = *(CFSocketNativeHandle *)data;
	CFSocketRef sn;
	CFRunLoopSourceRef source;
    
    const CFSocketContext context = {0, NULL, NULL, NULL, NULL};
    
	sn = CFSocketCreateWithNative(NULL, csock, kCFSocketDataCallBack, receiveDataData, &context);
    
    source = CFSocketCreateRunLoopSource(NULL, sn, 0);
    CFRunLoopAddSource(CFRunLoopGetCurrent(), source, kCFRunLoopDefaultMode);
    CFRelease(source);
    CFRelease(sn);
}


-(void)dealloc {
    if (self.sRef != NULL) {
        CFSocketInvalidate(self.sRef);
        CFRelease(self.sRef);
        self.sRef = NULL;
    }
}

@end
