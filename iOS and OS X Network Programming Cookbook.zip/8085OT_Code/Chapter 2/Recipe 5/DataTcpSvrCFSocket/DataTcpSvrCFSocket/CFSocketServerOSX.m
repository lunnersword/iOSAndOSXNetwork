//
//  CFSocketServerOSX.m
//  DataTcpSvrCFSocket
//
//  Created by Jon Hoffman on 4/24/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import "CFSocketServerOSX.h"
#import "CFSocketServer.h"

@implementation CFSocketServerOSX

-(id)init {
    newImage = YES;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(newImageRecieved:) name:NOTIFICATIONIMAGE object:nil ] ;
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^{
        CFSocketServer *cf = [[CFSocketServer alloc] initOnPort:2010 andServerType:SERVERTYPEIMAGE];
        if (cf.errorCode != NOERROR) {
            NSString *str = [NSString stringWithFormat:@"Error starting server.  Error code: %d",cf.errorCode];
            NSLog(@"%@",str);
        }
    });
    return self;
}



-(void)newImageRecieved:(NSNotification *)notification
{
    NSData *imgData = [notification object];
    NSLog(@"HERE:  %ld", (unsigned long)[imgData length]);
    if (newImage) {
        img = [[NSMutableData alloc] init];
        newImage = NO;
    }
    [img appendData:imgData];
    if ([imgData length] == 0) {
        NSString *appFile = @"/Users/hoffmanjon/Documents/test.png";
        
        [img writeToFile:appFile atomically:YES];
        newImage = YES;
    }
}

@end