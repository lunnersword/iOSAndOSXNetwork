//
//  CFSocketServerOSX.h
//  DataTcpSvrCFSocket
//
//  Created by Jon Hoffman on 4/24/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CFSocketServerOSX : NSObject {
    NSMutableData *img;
    bool newImage;
}

@end
