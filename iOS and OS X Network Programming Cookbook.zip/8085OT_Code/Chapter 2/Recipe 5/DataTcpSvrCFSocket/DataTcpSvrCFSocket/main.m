//
//  main.m
//  DataTcpSvrCFSocket
//
//  Created by Jon Hoffman on 4/24/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CFSocketServerOSX.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        CFSocketServerOSX *cf = [[CFSocketServerOSX alloc] init];
        while (1) {}
        
    }
    return 0;
}

