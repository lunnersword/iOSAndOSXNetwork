//
//  ViewController.h
//  DataTcpClientCFSocketIOS
//
//  Created by Jon Hoffman on 4/24/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController  <UIImagePickerControllerDelegate>

@end
