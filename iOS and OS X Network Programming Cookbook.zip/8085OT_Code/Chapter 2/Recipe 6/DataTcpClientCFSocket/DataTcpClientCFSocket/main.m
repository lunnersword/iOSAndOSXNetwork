//
//  main.m
//  DataTcpClientCFSocket
//
//  Created by Jon Hoffman on 4/24/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CFSocketClient.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        CFSocketClient *cf = [[CFSocketClient alloc] initWithAddr:@"127.0.0.1" andPort:2010];
        if (cf.errorcde == NOERRROR) {
            NSData *data = [NSData dataWithContentsOfFile:@"/Users/hoffmanjon/Documents/GreenGuyLarge2.png"];
       //        NSData *data = [NSData dataWithContentsOfFile:@"/Users/hoffmanjon/3circles.png"];
            [cf sendDataToSocket:cf.sockfd withData:data];
        }else {
            NSLog(@"Connection error:  %d", cf.errorcde);
        }

        
    }
    return 0;
}

