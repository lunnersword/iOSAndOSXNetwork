//
//  main.m
//  CFAddressResolution
//
//  Created by Jon Hoffman on 4/21/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CFNetworkUtilities.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        // insert code here...
        NSString *serverName = @"packtpub.com";
        CFNetworkUtilities *cfn = [[[CFNetworkUtilities alloc] init] autorelease];
        NSArray *results = [cfn addressesForHostname:serverName];
        NSMutableString *mutStr = [[[NSMutableString alloc] init] autorelease];
        if (cfn.errorCode == NOERROR) {
            for (NSString *addr in results) {
                [mutStr appendFormat:@"%@\n",addr];
            }
        } else {
            mutStr = [NSMutableString stringWithString:@"Error occured in host resolution"];
        }
        
        NSLog(@"packtpub.com resolves too:");
        NSLog(@"%@",mutStr);
        
    }
    return 0;
}

