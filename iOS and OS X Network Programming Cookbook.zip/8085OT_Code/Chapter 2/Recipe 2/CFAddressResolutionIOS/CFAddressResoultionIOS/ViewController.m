//
//  ViewController.m
//  CFAddressResoultionIOS
//
//  Created by Jon Hoffman on 4/18/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import "ViewController.h"
#import "CFNetworkUtilities.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(IBAction)resolveNamePressed:(id)sender {
    NSString *serverName = name.text;
    CFNetworkUtilities *cfn = [[[CFNetworkUtilities alloc] init] autorelease];
    NSArray *results = [cfn addressesForHostname:serverName];
    NSMutableString *mutStr = [[[NSMutableString alloc] init] autorelease];
    if (cfn.errorCode == NOERROR) {
        for (NSString *addr in results) {
            [mutStr appendFormat:@"%@\n",addr];
        }
    } else {
        mutStr = [NSMutableString stringWithString:@"Error occured in host resolution"];
    }
    
    resultsView.text = mutStr;
    [self.view endEditing:YES];
}


-(IBAction)resolveAddressPressed:(id)sender {
    NSString *serverAddr = address.text;
    CFNetworkUtilities *cfn = [[[CFNetworkUtilities alloc] init] autorelease];
    NSArray *results = [cfn hostnamesForAddress:serverAddr];
    NSMutableString *mutStr = [[[NSMutableString alloc] init] autorelease];
    if (cfn.errorCode == NOERROR) {
        for (NSString *addr in results) {
            [mutStr appendFormat:@"%@\n",addr];
        }
    } else {
        mutStr = [NSMutableString stringWithString:@"Error occured in address resolution"];
    }
    
    resultsView.text = mutStr;
    [self.view endEditing:YES];
}


@end
