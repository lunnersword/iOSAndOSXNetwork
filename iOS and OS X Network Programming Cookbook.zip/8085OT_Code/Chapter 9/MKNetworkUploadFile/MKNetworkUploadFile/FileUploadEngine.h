//
//  FileUploadEngine.h
//  MKNetworkUploadFile
//
//  Created by Jon Hoffman on 6/23/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import "MKNetworkEngine.h"

#define FILEUPLOADSERVER @"localhost:8080"
#define FILEUPLOADPATH @"/fileupload"

@interface FileUploadEngine : MKNetworkEngine

-(MKNetworkOperation *)postFileToServerWithParameters:(NSDictionary *)params;
-(MKNetworkOperation *)postFileToServerWithParameters:(NSDictionary *)params Path:(NSString *)path andSSL:(bool)ssl;

@end
