//
//  FileUploadEngine.m
//  MKNetworkUploadFile
//
//  Created by Jon Hoffman on 6/23/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import "FileUploadEngine.h"

@implementation FileUploadEngine

-(id)init {
    if (self = [super initWithHostName:FILEUPLOADSERVER]) {
        return self;
    } else {
        return nil;
    }
}

-(MKNetworkOperation *)postFileToServerWithParameters:(NSDictionary *)params {
    return [self postFileToServerWithParameters:params Path:FILEUPLOADPATH andSSL:NO];
}

-(MKNetworkOperation *)postFileToServerWithParameters:(NSDictionary *)params Path:(NSString *)path andSSL:(bool)ssl {
    MKNetworkOperation *operation = [self operationWithPath:path params:params httpMethod:@"POST" ssl:ssl];
    return operation;
}

@end
