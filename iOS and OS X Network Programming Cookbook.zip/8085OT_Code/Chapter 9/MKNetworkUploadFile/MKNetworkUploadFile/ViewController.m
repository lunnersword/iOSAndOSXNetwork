//
//  ViewController.m
//  MKNetworkUploadFile
//
//  Created by Jon Hoffman on 6/23/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import "ViewController.h"
#import "FileUploadEngine.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    NSData *imageData = UIImageJPEGRepresentation([UIImage imageNamed:@"IMG_1168.jpg"], 1.0);
    
	FileUploadEngine *fue = [[FileUploadEngine alloc] init];
    MKNetworkOperation *operation = [fue postFileToServerWithParameters:nil];
    
    [operation addData:imageData forKey:@"image" mimeType:@"image/jpeg" fileName:@"IMG_1168.jpg"];

    [operation addCompletionHandler:^(MKNetworkOperation *completedOperation)
     {
         NSLog(@"Complete");
     }errorHandler:^(MKNetworkOperation *errorOp, NSError* error) {
         
         UIAlertView *av = [[UIAlertView alloc] initWithTitle:@"Error" message:[NSString stringWithFormat:@"%@",error] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
         [av show];
     }];
    [fue enqueueOperation:operation];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
