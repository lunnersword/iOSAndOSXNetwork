//
//  ImageDownloadEngine.m
//  MKNetworkKitDownloadFile
//
//  Created by Jon Hoffman on 6/23/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import "ImageDownloadEngine.h"

@implementation ImageDownloadEngine

-(id)init {
    if (self = [super initWithHostName:FILEDOWNLOADSERVER]) {
        return self;
    } else {
        return nil;
    }
}


-(MKNetworkOperation *)downloadFileAtPath:(NSString *)path {
    MKNetworkOperation *operation = [self operationWithPath:path params:nil httpMethod:@"GET" ssl:NO];
    return operation;
}
@end
