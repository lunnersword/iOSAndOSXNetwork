//
//  ImageDownloadEngine.h
//  MKNetworkKitDownloadFile
//
//  Created by Jon Hoffman on 6/23/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import "MKNetworkEngine.h"

#define FILEDOWNLOADSERVER @"a2.mzstatic.com"

@interface ImageDownloadEngine : MKNetworkEngine

-(MKNetworkOperation *)downloadFileAtPath:(NSString *)path;

@end
