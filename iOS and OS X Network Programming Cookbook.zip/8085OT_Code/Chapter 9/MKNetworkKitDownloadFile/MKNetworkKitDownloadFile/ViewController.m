//
//  ViewController.m
//  MKNetworkKitDownloadFile
//
//  Created by Jon Hoffman on 6/23/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import "ViewController.h"
#import "ImageDownloadEngine.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	ImageDownloadEngine *ide = [[ImageDownloadEngine alloc] init];
    MKNetworkOperation *operation = [ide downloadFileAtPath:@"/us/r1000/107/Features/22/58/71/dj.xdzqqclr.100x100-75.jpg"];
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *appFile = [documentsDirectory stringByAppendingPathComponent:@"jb.jpg"];
    
    [operation addDownloadStream:[NSOutputStream outputStreamToFileAtPath:appFile append:YES]];
    [operation addCompletionHandler:^(MKNetworkOperation *completedOperation)
     {
         NSLog(@"completed");
     }errorHandler:^(MKNetworkOperation *errorOp, NSError* error) {
         
         UIAlertView *av = [[UIAlertView alloc] initWithTitle:@"Error Retrieving Weather" message:[NSString stringWithFormat:@"%@",error] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
         [av show];
     }];
    [ide enqueueOperation:operation];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
