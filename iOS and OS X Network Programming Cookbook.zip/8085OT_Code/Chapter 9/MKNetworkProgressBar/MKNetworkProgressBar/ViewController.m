//
//  ViewController.m
//  MKNetworkProgressBar
//
//  Created by Jon Hoffman on 6/24/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import "ViewController.h"
#import "FileDownloadEngine.h"

//Set this to the url to download sample code before final version is published
#define DOWNLOADPATH @"/studio3/standalone/3.4.1/mac/Aptana_Studio_3_Setup_3.4.1.dmg"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    FileDownloadEngine *fde = [[FileDownloadEngine alloc]init];
    MKNetworkOperation *operation = [fde downloadFileAtURL:DOWNLOADPATH andSSL:NO];
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *filePath = [documentsDirectory stringByAppendingPathComponent:@"myFile.dmg"];

    [operation addDownloadStream:[NSOutputStream outputStreamToFileAtPath:filePath append:YES]];
    [operation onDownloadProgressChanged:^(double progress) {
        progressView.progress = progress;
        progressLabel.text = [NSString stringWithFormat:@"%0.2f",(progress*100)];
    }];
	[fde enqueueOperation:operation];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
