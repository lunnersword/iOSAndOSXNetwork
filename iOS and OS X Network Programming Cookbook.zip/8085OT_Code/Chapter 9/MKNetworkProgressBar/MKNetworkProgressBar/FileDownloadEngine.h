//
//  FileDownloadEngine.h
//  MKNetworkProgressBar
//
//  Created by Jon Hoffman on 6/24/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import "MKNetworkEngine.h"

#define DOWNLOADHOST @"download.aptana.com"

@interface FileDownloadEngine : MKNetworkEngine

-(MKNetworkOperation *)downloadFileAtURL:(NSString *)urlString andSSL:(bool)ssl;

@end
