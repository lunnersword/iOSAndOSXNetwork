//
//  ViewController.h
//  MKNetworkProgressBar
//
//  Created by Jon Hoffman on 6/24/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController {
    IBOutlet UIProgressView *progressView;
    IBOutlet UILabel *progressLabel;
}

@end
