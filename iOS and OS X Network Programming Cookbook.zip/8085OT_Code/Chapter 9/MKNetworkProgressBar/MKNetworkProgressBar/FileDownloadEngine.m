//
//  FileDownloadEngine.m
//  MKNetworkProgressBar
//
//  Created by Jon Hoffman on 6/24/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import "FileDownloadEngine.h"

@implementation FileDownloadEngine

-(id)init {
    if (self = [super initWithHostName:DOWNLOADHOST]) {
        return self;
    } else {
        return nil;
    }
}

-(MKNetworkOperation *)downloadFileAtURL:(NSString *)urlString andSSL:(bool)ssl {
    MKNetworkOperation *operation = [self operationWithPath:urlString params:nil httpMethod:@"GET" ssl:ssl];
    return operation;
}
@end
