//
//  ViewController.h
//  UseMKNetworkEngine
//
//  Created by Jon Hoffman on 6/23/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ITunesEngine.h"

@interface ViewController : UIViewController {
    IBOutlet UITableView *tableView;
}

@property (strong, nonatomic) NSArray *albums;
@property (strong, nonatomic) ITunesEngine *itunes;

@end
