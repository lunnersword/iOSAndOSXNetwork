//
//  ViewController.m
//  UseMKNetworkEngine
//
//  Created by Jon Hoffman on 6/23/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import "ViewController.h"
#import "UIImageView+MKNetworkKitAdditions.h"


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
   
//    NSDictionary *parameters = [NSDictionary dictionaryWithObjectsAndKeys:@"jimmy+buffett",@"term",@"album", @"entity", nil];
    NSDictionary *parameters = @{@"term":@"jimmy+buffett",@"entity":@"album"};
    self.itunes = [[ITunesEngine alloc] init];
    MKNetworkOperation *operation = [self.itunes searchITunesWithParams:parameters];
    
    [operation addCompletionHandler:^(MKNetworkOperation *completedOperation)
     {
         NSData *responseData = [completedOperation responseData];
         NSError *error;
         NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:responseData options:0 error:&error];
         self.albums = dict[@"results"];
        
         [tableView reloadData];
     }errorHandler:^(MKNetworkOperation *errorOp, NSError* error) {
         
         UIAlertView *av = [[UIAlertView alloc] initWithTitle:@"Network Error" message:[NSString stringWithFormat:@"%@",error] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
         [av show];
     }];
    [self.itunes enqueueOperation:operation];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
       
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return [self.albums count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 75.0; //returns floating point which will be used for a cell row height at specified row index
}


- (UITableViewCell *)tableView:(UITableView *)lTableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellID = @"Cell";
    UITableViewCell *cell = [lTableView dequeueReusableCellWithIdentifier:cellID];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellID];
    }
    
    NSDictionary *album = [self.albums objectAtIndex:indexPath.row];
    
    cell.textLabel.numberOfLines = 3;
    cell.textLabel.font = [UIFont systemFontOfSize:14];
    cell.textLabel.text = [album objectForKey:@"collectionName"];
    
    cell.detailTextLabel.font = [UIFont boldSystemFontOfSize:16];
    
    cell.detailTextLabel.text = [NSString stringWithFormat:@"Tracks:  %@",[album objectForKey:@"trackCount"]];
    NSURL *url = [[NSURL alloc] initWithString:[album objectForKey:@"artworkUrl60"]];
    [cell.imageView setImageFromURL:url placeHolderImage:[UIImage imageNamed:@"loading"] usingEngine:self.itunes animation:NO ];

    return cell;
}



@end
