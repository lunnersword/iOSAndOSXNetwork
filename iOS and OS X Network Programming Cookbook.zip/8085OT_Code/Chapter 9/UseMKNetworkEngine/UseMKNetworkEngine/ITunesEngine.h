//
//  ITunesEngine.h
//  UseMKNetworkEngine
//
//  Created by Jon Hoffman on 6/23/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import "MKNetworkEngine.h"

#define ITUNESSERVER @"itunes.apple.com"
#define ITUNESSEARCHPATH @"/search"

@interface ITunesEngine : MKNetworkEngine

-(MKNetworkOperation *)searchITunesWithParams:(NSDictionary *)parameters;
-(MKNetworkOperation *)connectToITunesWithPath:(NSString *)path andParms:(NSDictionary *)parameters;

@end
