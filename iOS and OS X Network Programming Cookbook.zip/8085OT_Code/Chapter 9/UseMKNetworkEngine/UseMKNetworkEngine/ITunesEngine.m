//
//  ITunesEngine.m
//  UseMKNetworkEngine
//
//  Created by Jon Hoffman on 6/23/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import "ITunesEngine.h"

@implementation ITunesEngine

-(id)init {
    if (self = [super initWithHostName:ITUNESSERVER]) {
        [self useCache];
        return self;
    } else {
        return nil;
    }
}

-(MKNetworkOperation *)searchITunesWithParams:(NSDictionary *)parameters {
    return [self connectToITunesWithPath:ITUNESSEARCHPATH andParms:parameters];
}

-(MKNetworkOperation *)connectToITunesWithPath:(NSString *)path andParms:(NSDictionary *)parameters {
    MKNetworkOperation *operation = [self operationWithPath:path params:parameters httpMethod:@"GET" ssl:NO];
    return operation;
}

//for image cache
-(NSString *)cacheDirectoryName {
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *cacheDirectoryName = [documentsDirectory stringByAppendingPathComponent:@"Hoffman.Jon.ItunesCache"];
    return cacheDirectoryName;
}

/*MKNetworkKit caching is super light-weight and it caches your responses in a NSMutableDictionary. Doesn’t that lead to high memory usage? Yes. of-course, but MKNetworkKit is clever. It observes the UIApplicationDidReceiveMemoryWarningNotification and flushes the dictionary to disk. The next time you make a request to the cached URL, the cached data is brought back to memory. So in-effect, it has a in-memory cache and disk cache and uses a least recently used algorithm to flush items to disk. The MKNetworkEngine class has methods that can be over-ridden to control the cache cost. 
 Set to a positive number to cache more to memory.  0 forces cache to hard storage.
 */
-(int)cacheMemoryCost {
    return 0;
}

@end
