//
//  ViewController.h
//  Bluetooth Peer
//
//  Created by Jon Hoffman on 5/7/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <GameKit/GameKit.h>

@interface ViewController : UIViewController <GKPeerPickerControllerDelegate, GKSessionDelegate> {
    IBOutlet UIButton *connectionButton, *sendButton;
    IBOutlet UITextField *inputText;
    IBOutlet UITextView *conversationText;
    bool hasPeerConnection;
}

@property (strong, nonatomic) GKPeerPickerController *mPeerPicker;
@property (strong, nonatomic) GKSession *mSession;

@end
