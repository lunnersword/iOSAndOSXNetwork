//
//  ViewController.m
//  Bluetooth Peer
//
//  Created by Jon Hoffman on 5/7/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import "ViewController.h"

#define SESSIONID @"PacktPubPeer"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(IBAction)initiatePeerSession {
    NSLog(@"Peer session initiating");
    if(hasPeerConnection) {
        [self sessionDisconnect];
    } else {
        [self sessionConnect];
    }
    
}

-(void)sessionConnect {
    self.mPeerPicker = [[GKPeerPickerController alloc]init];
    self.mPeerPicker.delegate = self;
    self.mPeerPicker.connectionTypesMask = GKPeerPickerConnectionTypeNearby;
    [self.mPeerPicker show];
}
-(void)sessionDisconnect {
    [self.mSession disconnectFromAllPeers];
    hasPeerConnection = NO;
    [connectionButton setTitle:@"Connect" forState:UIControlStateNormal];
}

-(GKSession *) peerPickerController:(GKPeerPickerController *)picker sessionForConnectionType:(GKPeerPickerConnectionType)type {
    self.mSession = [[GKSession alloc]initWithSessionID:SESSIONID displayName:nil sessionMode:GKSessionModePeer];
    return self.mSession;
}

-(void)peerPickerController:(GKPeerPickerController *)picker didConnectPeer:(NSString *)peerID toSession:(GKSession *)session {
    [self.mSession setDataReceiveHandler:self withContext:NULL];
    [self.mPeerPicker dismiss];
    self.mPeerPicker = nil;
    
    hasPeerConnection = true;
    [connectionButton setTitle:@"Disconnect" forState:UIControlStateNormal];

}

- (void)receiveData:(NSData *)data fromPeer:(NSString *)peer inSession: (GKSession *)session context:(void *)context {
    NSString *receivedStr = [NSString stringWithUTF8String:[data bytes]];
    
    NSLog(@"Received >>>>>>>> %@",receivedStr);
    
    NSString *conversation = [NSString stringWithFormat:@"%@\nReceived: %@",conversationText.text,receivedStr];
    conversationText.text = conversation;
 }

-(IBAction)sendDataToPeer:(id)sender {
    NSString *text = inputText.text;
    NSError *error;
    [self.mSession sendDataToAllPeers:[text dataUsingEncoding:NSStringEncodingConversionAllowLossy] withDataMode:GKSendDataReliable error:&error];
    
    NSString *conversation = [NSString stringWithFormat:@"%@\nSent: %@",conversationText.text,inputText.text];
    conversationText.text = conversation;
    [self.view endEditing:YES];
    inputText.text = @"";
}

- (void)session:(GKSession *)session peer:(NSString *)peerID didChangeState:(GKPeerConnectionState)state {

    switch (state) {
        case GKPeerStateConnected:
            NSLog(@"Connected");
            break;
            
        case GKPeerStateDisconnected:
            NSLog(@"Disconnected");
            break;
            
        case GKPeerStateAvailable:
            NSLog(@"Available");
            break;
            
        case GKPeerStateConnecting:
            NSLog(@"Connection");
            break;
            
        case GKPeerStateUnavailable:
            NSLog(@"Unavailable");
            break;
            
    }
}
-(void)session:(GKSession *)session didReceiveConnectionRequestFromPeer:(NSString *)peerID {
    NSLog(@"received connection request from %@", peerID);
}
-(void)session:(GKSession *)session connectionWithPeerFailed:(NSString *)peerID withError:(NSError *)error {
    NSLog(@"Connection with peer failed with error:  %@", error);
}

-(void)session:(GKSession *)session didFailWithError:(NSError *)error {
    NSLog(@"session failed with error:  %@", error);
}


@end
