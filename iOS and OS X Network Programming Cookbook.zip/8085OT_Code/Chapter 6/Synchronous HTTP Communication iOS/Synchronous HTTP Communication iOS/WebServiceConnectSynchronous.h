//
//  WebServiceConnectSynchronous.h
//  Synchronous HTTP Communication iOS
//
//  Created by Jon Hoffman on 5/6/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import <Foundation/Foundation.h>

#define WEBSERVICESUCCESS 200

@interface WebServiceConnectSynchronous : NSObject

@property int statusCde;
@property (strong, nonatomic) NSError *error;

-(NSString *)sendGetRequest:(NSDictionary *)params toUrl:(NSString *)urlString;
-(NSString *)sendPostRequest:(NSDictionary *)params toUrl:(NSString *)urlString;

@end
