//
//  ViewController.m
//  Synchronous HTTP Communication iOS
//
//  Created by Jon Hoffman on 5/6/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import "ViewController.h"
#import "WebServiceConnectSynchronous.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	
    WebServiceConnectSynchronous *ws = [[WebServiceConnectSynchronous alloc] init];
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
    [dict setValue:@"Jon" forKey:@"name"];
    [dict setValue:@"Hello" forKey:@"greeting"];
    NSString *response = [ws sendGetRequest:dict toUrl:@"http://localhost:8080/TestWebServices/testservice/hello2"];
    if (ws.statusCde != WEBSERVICESUCCESS) {
        NSLog(@"error with request:  %@", ws.error);
    }
    NSLog(@"Respose:  %@", response);
    
    NSString *response2 = [ws sendPostRequest:dict toUrl:@"http://localhost:8080/TestWebServices/testservice/hellopost"];
    if (ws.statusCde != WEBSERVICESUCCESS) {
        NSLog(@"error with request:  %@", ws.error);
    }
    NSLog(@"Response2:  %@", response2);
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
