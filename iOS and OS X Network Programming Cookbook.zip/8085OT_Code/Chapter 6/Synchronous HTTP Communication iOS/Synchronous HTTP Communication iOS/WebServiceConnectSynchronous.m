//
//  WebServiceConnectSynchronous.m
//  Synchronous HTTP Communication iOS
//
//  Created by Jon Hoffman on 5/6/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import "WebServiceConnectSynchronous.h"

@implementation WebServiceConnectSynchronous


-(NSString *)sendGetRequest:(NSDictionary *)params toUrl:(NSString *)urlString {
    
    NSMutableString *paramString = [NSMutableString stringWithString:@"?"];
    NSArray *keys = [params allKeys];
    for (NSString *key in keys) {
        [paramString appendFormat:@"%@=%@&",key,[params valueForKey:key]];
    }

    NSString *urlRequest = [NSString stringWithFormat:@"%@%@",urlString,[paramString substringToIndex:[paramString length]-1]];
    
    NSMutableURLRequest *request =[NSMutableURLRequest requestWithURL:[NSURL URLWithString:urlRequest]];
    [request setHTTPMethod:@"GET"];

    NSURLResponse *res;
    NSError *lError;
    NSData *resp = [NSURLConnection sendSynchronousRequest:request returningResponse:&res error:
                    &lError];
    self.error = lError;
    
    NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *)res;
    self.statusCde = [httpResponse statusCode];
    
    return [[NSString alloc] initWithData:resp encoding:NSUTF8StringEncoding];
}

-(NSString *)sendPostRequest:(NSDictionary *)params toUrl:(NSString *)urlString {
    
    NSMutableString *paramString = [NSMutableString stringWithString:@""];
    NSArray *keys = [params allKeys];
    for (NSString *key in keys) {
        [paramString appendFormat:@"%@=%@&",key,[params valueForKey:key]];
    }
    NSString *postString = @"";
    if ([paramString length] > 0)
        postString = [paramString substringToIndex:[paramString length]-1];

    NSMutableURLRequest *request =[NSMutableURLRequest requestWithURL:[NSURL URLWithString:urlString]];
    [request setHTTPMethod:@"POST"];
    [request setHTTPBody:[postString dataUsingEncoding:NSUTF8StringEncoding]];

    NSURLResponse *res;
    NSError *lError;
    NSData *resp = [NSURLConnection sendSynchronousRequest:request returningResponse:&res error:
                    &lError];
    self.error = lError;
    
    NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *)res;
    self.statusCde = [httpResponse statusCode];

    return [[NSString alloc] initWithData:resp encoding:NSUTF8StringEncoding];
}


@end
