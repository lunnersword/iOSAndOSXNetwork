//
//  WebServiceConnectAsynchronous.h
//  Asynchronous HTTP Communication
//
//  Created by Jon Hoffman on 5/7/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import <Foundation/Foundation.h>

#define WEBSERVICESUCCESS 200

#define WEBSERVICENOTIFICATIONSUCCESS @"WebserviceConnectSuccess" 
#define WEBSERVICENOTIFICATIONERROR @"WebserviceConnectError"

@interface WebServiceConnectAsynchronous : NSObject {
    NSMutableData *responseData;
}

@property int errorCde;

-(void)sendGetRequest:(NSDictionary *)params toUrl:(NSString *)urlString;
-(void)sendPostRequest:(NSDictionary *)params toUrl:(NSString *)urlString;

@end
