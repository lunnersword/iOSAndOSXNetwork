//
//  ViewController.m
//  Asynchronous HTTP Communication
//
//  Created by Jon Hoffman on 5/7/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import "ViewController.h"
#import "WebServiceConnectAsynchronous.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(webserviceFailure:)
                                                 name:WEBSERVICENOTIFICATIONERROR
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(webserviceSuccess:)
                                                 name:WEBSERVICENOTIFICATIONSUCCESS
                                               object:nil];
    
    WebServiceConnectAsynchronous *ws = [[WebServiceConnectAsynchronous alloc] init];
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
    [dict setValue:@"Jon" forKey:@"name"];
    [dict setValue:@"Hello" forKey:@"greeting"];
    [ws sendGetRequest:dict toUrl:@"http://localhost:8080/TestWebServices/testservice/hello2"];
    
    [ws sendPostRequest:dict toUrl:@"http://localhost:8080/TestWebServices/testservice/hellopost"];

}

-(void)webserviceFailure:(NSNotification *)notification {
    NSString *resp = [notification object];
    NSLog(@"Error:  %@",resp);
}

-(void)webserviceSuccess:(NSNotification *)notification {
    NSString *resp = [notification object];
    NSLog(@"Response:  %@",resp);
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
