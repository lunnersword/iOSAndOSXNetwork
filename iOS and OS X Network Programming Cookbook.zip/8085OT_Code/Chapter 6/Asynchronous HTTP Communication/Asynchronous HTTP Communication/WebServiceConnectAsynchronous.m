//
//  WebServiceConnectAsynchronous.m
//  Asynchronous HTTP Communication
//
//  Created by Jon Hoffman on 5/7/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import "WebServiceConnectAsynchronous.h"

@implementation WebServiceConnectAsynchronous

-(void)sendGetRequest:(NSDictionary *)params toUrl:(NSString *)urlString {
    
    responseData = [[NSMutableData alloc]init];
    NSMutableString *paramString = [NSMutableString stringWithString:@"?"];
    NSArray *keys = [params allKeys];
    for (NSString *key in keys) {
        [paramString appendFormat:@"%@=%@&",key,[params valueForKey:key]];
    }
    
    NSString *urlRequest = [NSString stringWithFormat:@"%@%@",urlString,[paramString substringToIndex:[paramString length]-1]];
    
    NSMutableURLRequest *request =[NSMutableURLRequest requestWithURL:[NSURL URLWithString:urlRequest]];
    [request setHTTPMethod:@"GET"];

    [[NSURLConnection alloc] initWithRequest:request delegate:self] ;
}

-(void)sendPostRequest:(NSDictionary *)params toUrl:(NSString *)urlString {
    
    responseData = [[NSMutableData alloc]init];
    NSMutableString *paramString = [NSMutableString stringWithString:@""];
    NSArray *keys = [params allKeys];
    for (NSString *key in keys) {
        [paramString appendFormat:@"%@=%@&",key,[params valueForKey:key]];
    }
    NSString *postString = @"";
    if ([paramString length] > 0)
        postString = [paramString substringToIndex:[paramString length]-1];
    
    NSMutableURLRequest *request =[NSMutableURLRequest requestWithURL:[NSURL URLWithString:urlString]];
    [request setHTTPMethod:@"POST"];
    [request setHTTPBody:[postString dataUsingEncoding:NSUTF8StringEncoding]];
    [[NSURLConnection alloc] initWithRequest:request delegate:self] ;
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
	NSLog(@"Received Response - WebServiceConnect");
    [responseData setLength:0];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [responseData appendData:data];
    NSString*tmp = [[NSString alloc] initWithData : responseData encoding:NSUTF8StringEncoding];
    NSLog(@"Resonse so far:  %@", tmp);
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
	[[NSNotificationCenter defaultCenter] postNotificationName:WEBSERVICENOTIFICATIONERROR object: error ];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
	NSString *res = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
	NSLog(@"Results:  '%@'", res);
    [[NSNotificationCenter defaultCenter] postNotificationName:WEBSERVICENOTIFICATIONSUCCESS object:res];
}

- (NSURLRequest *)connection: (NSURLConnection *)connection willSendRequest: (NSURLRequest *)request redirectResponse: (NSURLResponse *)redirectResponse;
{
    NSLog(@"Redirecting:  %@", request.URL);
    return request;
}
- (NSCachedURLResponse *)connection:(NSURLConnection *)connection willCacheResponse:(NSCachedURLResponse*)cachedResponse {
    return nil;
}



@end
