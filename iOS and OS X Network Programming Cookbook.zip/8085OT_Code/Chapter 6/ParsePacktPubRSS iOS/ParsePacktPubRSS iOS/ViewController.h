//
//  ViewController.h
//  ParsePacktPubRSS iOS
//
//  Created by Jon Hoffman on 6/18/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ParseRSS.h"

@interface ViewController : UIViewController<UITableViewDataSource, UITableViewDelegate>{
    IBOutlet UITableView *tableView;
    IBOutlet UIActivityIndicatorView *activityInd;
    IBOutlet UIImageView *activityBack;
    IBOutlet UILabel *activityLab;
    
    ParseRSS *parseRss;
    UIFont *titleFont, *subFont;
    NSDateFormatter *displayDateFormat;
}

@end