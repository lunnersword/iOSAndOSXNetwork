//
//  ViewController.m
//  ParsePacktPubRSS iOS
//
//  Created by Jon Hoffman on 6/18/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import "ViewController.h"
#import "RSSItem.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    displayDateFormat = [[NSDateFormatter alloc] init];
    [displayDateFormat setDateFormat:@"EEE dd MMM yyyy"];
	[self activityOn];
    [NSThread detachNewThreadSelector:@selector(parseTwitter) toTarget:self withObject:nil];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

-(void)activityOff {
    [activityInd stopAnimating];
    activityInd.hidden = YES;
    activityBack.hidden = YES;
    activityLab.hidden = YES;
}
-(void)activityOn {
    [activityInd startAnimating];
    activityInd.hidden = NO;
    activityBack.hidden = NO;
    activityLab.hidden = NO;
}

-(void)parseTwitter {
    parseRss = [[ParseRSS alloc] initWithUrl:@"https://www.packtpub.com/rss.xml" ];
    [self performSelectorOnMainThread:@selector(reloadTable) withObject:nil waitUntilDone:NO ];
    
}

-(void)reloadTable {
    
    [tableView reloadData];
    [self activityOff];
}



- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 95;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [parseRss.items count];
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [self createMultilinesCell:CellIdentifier];
    }
    for(UIView *sv in [cell subviews]) {
        if ([sv isKindOfClass:[UIImageView class]])
            [sv removeFromSuperview];
    }
    
    
    NSUInteger row = [indexPath row];
    
    cell.textLabel.numberOfLines = 1;
	cell.textLabel.textColor = [UIColor blackColor];
	cell.detailTextLabel.numberOfLines = 4;
	cell.detailTextLabel.textColor = [UIColor blackColor];
    
    RSSItem *item = [parseRss.items objectAtIndex:row];
    NSLog(@"%@",item.date);
    [cell.textLabel setText:[displayDateFormat stringFromDate:item.date]];
    
    [cell.detailTextLabel setText:item.description];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
 	return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
}


- (UITableViewCell*) createMultilinesCell :(NSString*)cellIdentifier
{
	UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier];
    
	cell.textLabel.numberOfLines = 0;
	cell.textLabel.font = [self titleFont];
    
	cell.detailTextLabel.numberOfLines = 0;
	cell.detailTextLabel.font = [self subFont];
	return cell;
}





-(UIFont*)titleFont;
{
	if (!titleFont)
		titleFont = [UIFont boldSystemFontOfSize:14];
	return titleFont;
}


-(UIFont*)subFont;
{
	if (!subFont)
		subFont = [UIFont systemFontOfSize:11];
	return subFont;
    
}



@end
