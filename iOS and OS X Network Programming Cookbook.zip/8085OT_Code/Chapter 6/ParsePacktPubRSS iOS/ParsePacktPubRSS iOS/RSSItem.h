//
//  RSSItem.h
//  ParsePacktPubRSS iOS
//
//  Created by Jon Hoffman on 6/18/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RSSItem : NSObject

@property (strong, nonatomic) NSString *title, *description;
@property (strong, nonatomic) NSDate *date;

@end
