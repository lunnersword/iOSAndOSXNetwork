//
//  RSSItem.m
//  ParsePacktPubRSS iOS
//
//  Created by Jon Hoffman on 6/18/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import "RSSItem.h"

@implementation RSSItem

-(instancetype)init {
    if ( self = [super init] ) {
        self.title = @"No Title";
        self.description = @"No Description";
        self.date = [[NSDate alloc] init];
    }
    return self;
}

@end
