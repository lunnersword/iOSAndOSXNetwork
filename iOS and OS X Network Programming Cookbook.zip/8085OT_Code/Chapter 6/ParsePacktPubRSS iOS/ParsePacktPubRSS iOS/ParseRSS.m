//
//  ParseRSS.m
//  ParsePacktPubRSS iOS
//
//  Created by Jon Hoffman on 6/18/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import "ParseRSS.h"
#import "RSSItem.h"

#define ITEMSEPERATOR @"item"
#define ITEMTITLEKEY @"title"
#define ITEMDESCRIPTIONKEY @"description"
#define ITEMDATEKEY @"pubDate"

#define RSSDATEFORMATTER @"EEE, dd MMM yyyy HH:mm:ss Z"

@implementation ParseRSS


-(id)initWithUrl:(NSString *)url {
    if(self = [super init]) {
		currentElementData = [[NSMutableDictionary alloc] init];
        currentElementString = [[NSMutableString alloc] init];
        formatter = [[NSDateFormatter alloc] init];
        [formatter setDateFormat:RSSDATEFORMATTER];
	}
    
    [self parseXMLFileAtURL:url];
	return self;
}
- (void)parseXMLFileAtURL:(NSString *)URL {
	self.items = [[NSMutableArray alloc] init];
    
	NSURL *xmlURL = [NSURL URLWithString:URL];
    NSData *myData = [NSData dataWithContentsOfURL:xmlURL];
    
	rssParser = [[NSXMLParser alloc] initWithData:myData];
	[rssParser setDelegate:self];
	[rssParser parse];
}
- (void)parserDidStartDocument:(NSXMLParser *)parser {
	NSLog(@"found file and started parsing");
}
- (void)parser:(NSXMLParser *)parser parseErrorOccurred:(NSError *)parseError {
	NSString * errorString = [NSString stringWithFormat:@"Unable to download RSS feed from web site (Error code %i )", [parseError code]];
    NSLog(@"Error:  %@", errorString);
    
}
- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict{
	currentElement = [elementName copy];
    currentElementString = [NSMutableString stringWithString:@""];
	if ([elementName isEqualToString:ITEMSEPERATOR])
	{
        [currentElementData removeAllObjects];
   	}
}
- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName{
	if ([elementName isEqualToString:ITEMSEPERATOR])
	{
        RSSItem *item = [[RSSItem alloc] init];
        item.description = [currentElementData objectForKey:ITEMDESCRIPTIONKEY];
        item.title = [currentElementData objectForKey:ITEMTITLEKEY];
        item.date = [formatter dateFromString:[currentElementData objectForKey:ITEMDATEKEY]];
         [self.items addObject:item];
	}
    NSString *string = [currentElementString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] ;
    if([currentElement isEqualToString:ITEMDATEKEY])
        [currentElementData setObject:[string copy] forKey:ITEMDATEKEY];
    if([currentElement isEqualToString:ITEMTITLEKEY])
        [currentElementData setObject:[string copy] forKey:ITEMTITLEKEY];
    if([currentElement isEqualToString:ITEMDESCRIPTIONKEY])
        [currentElementData setObject:[string copy] forKey:ITEMDESCRIPTIONKEY];
}
- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
	[currentElementString appendString:string];
}
- (void)parserDidEndDocument:(NSXMLParser *)parser
{
    NSLog(@"Items %d",[self.items count]);
}

@end

