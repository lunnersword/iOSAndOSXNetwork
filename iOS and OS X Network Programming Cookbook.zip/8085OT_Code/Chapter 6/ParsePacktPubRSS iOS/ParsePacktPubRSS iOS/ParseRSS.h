//
//  ParseRSS.h
//  ParsePacktPubRSS iOS
//
//  Created by Jon Hoffman on 6/18/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ParseRSS : NSObject<NSXMLParserDelegate> {
    NSXMLParser * rssParser;
    NSString * currentElement;
    NSMutableString *currentElementString;
    NSMutableDictionary *currentElementData;
    
    NSDateFormatter *formatter;
}

@property (strong, nonatomic) NSMutableArray *items;

-(id)initWithUrl:(NSString *)urlString;

@end
