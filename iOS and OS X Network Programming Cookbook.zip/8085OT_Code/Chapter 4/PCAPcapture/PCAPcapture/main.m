//
//  main.m
//  PCAPcapture
//
//  Created by Jon Hoffman on 7/13/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <pcap.h>
#import <netinet/in.h>
#import <arpa/inet.h>
#import "PCAP_Headers.h"

#define SNAPLEN 65535
#define PROMISC 1
#define TIMEOUT 500
#define FOREVER 1


void decodeICMP(const u_char *packet) {
    struct pcap_ip *ip = (struct pcap_ip *)(packet + ETHERNET_SIZE);
    int offset = GET_IP_HEADER_LENGTH(ip)*4;
    struct pcap_icmp *icmp = (struct pcap_icmp *)(packet + ETHERNET_SIZE + offset);
    
    NSString *typeStr = @"ICMP Unknown";
    int iType = icmp->icmp_type;
    switch (iType) {
        case ICMP_ECHO_REPLY_TYPE:
            typeStr=@"ICMP Reply";
            break;
        case ICMP_ECHO_REQUEST_TYPE:
            typeStr=@"ICMP Request";
            break;
        case ICMP_REDIRECT_TYPE:
            typeStr=@"ICMP Redirect";
            break;
        case ICMP_DESTINATION_UNREACHABLE_TYPE:
            typeStr=@"ICMP Unreachable";
            break;
        case ICMP_TRACEROUTE_TYPE:
            typeStr=@"ICMP Traceroute";
            break;
        case ICMP_TIME_EXCEEDED_TYPE:
            typeStr=@"ICMP Time Exceeded";
            break;
            
        default:
            break;
    }
    NSLog(@"ICMP packet of type:  %@", typeStr);
}

void decodeUdp(const u_char *packet) {
    struct pcap_ip *ip = (struct pcap_ip *)(packet + ETHERNET_SIZE);
    int offset = GET_IP_HEADER_LENGTH(ip)*4;
    struct pcap_udp *udp = (struct pcap_udp *)(packet + ETHERNET_SIZE + offset);

    int from = ntohs(udp->udp_sport);
    int to = ntohs(udp->udp_dport);
    NSLog(@"UDP packet from port:  %d  to port:  %d", from, to);
}

void decodeTcp(const u_char *packet) {
    struct pcap_ip *ip = (struct pcap_ip *)(packet + ETHERNET_SIZE);
    int offset = GET_IP_HEADER_LENGTH(ip)*4;
    struct pcap_tcp *tcp = (struct pcap_tcp *)(packet + ETHERNET_SIZE + offset);

    int from =ntohs(tcp->tcp_sport);
    int to = ntohs(tcp->tcp_dport);
    NSString *flags = [NSString stringWithFormat:@"%s%s%s%s%s%s",(tcp->tcp_flags & TCP_FIN) ? "F" : "", /* FIN */
                          (tcp->tcp_flags & TCP_SYN) ? "S" : "", /* SYN */
                          (tcp->tcp_flags & TCP_RST) ? "R" : "", /* RST */
                          (tcp->tcp_flags & TCP_PUSH) ? "P" : "", /* PSH */
                          (tcp->tcp_flags & TCP_ACK) ? "A" : "", /* ACK */
                          (tcp->tcp_flags & TCP_URG) ? "U" : ""]; /* URG */
    NSLog(@"TCP packet from port:  %d  to port:  %d  with flags:  %@", from, to, flags);
}

void decodeArp(const u_char *packet) {
    const struct pcap_arp *arp = (struct pcap_arp *)(packet + ETHERNET_SIZE);
    switch (ntohs(arp->arp_type)) {
        case ARP_REQUEST:
            NSLog(@"ARP Request");
            NSLog(@"From:  %d.%d.%d.%d",arp->arp_spa[0],arp->arp_spa[1],arp->arp_spa[2],arp->arp_spa[3]);
            NSLog(@"To:    %d.%d.%d.%d",arp->arp_dpa[0],arp->arp_dpa[1],arp->arp_dpa[2],arp->arp_dpa[3]);
            break;
            
        case ARP_REPLY:
            NSLog(@"ARP Response");
            NSLog(@"From:  %02X:%02X:%02X:%02X:%02X:%02X",arp->arp_sha[0],arp->arp_sha[1],arp->arp_sha[2],arp->arp_sha[3],arp->arp_sha[4],arp->arp_sha[5]);
            NSLog(@"To:    %d.%d.%d.%d",arp->arp_dpa[0],arp->arp_dpa[1],arp->arp_dpa[2],arp->arp_dpa[3]);
            break;
            
        default:
            NSLog(@"ARP Type:  %d",arp->arp_type);
            break;
    }

}

void decodeIp(const u_char *packet) {
    const struct pcap_ip *ip = (struct pcap_ip *)(packet + ETHERNET_SIZE);
    uint version;
    
    version = GET_IP_VERSION(ip);
    
    NSString *from = [NSString stringWithFormat:@"%s",inet_ntoa(ip->ip_src)];
    NSString *to = [NSString stringWithFormat:@"%s",inet_ntoa(ip->ip_dst)];
    
    switch (ip->ip_p) {
        case IPPROTO_TCP:
            NSLog(@"Found TCP packet from: %@  to:  %@",from,to);
            decodeTcp(packet);
            break;
        case IPPROTO_UDP:
            NSLog(@"Found UDP packet from: %@  to:  %@",from,to);
            decodeUdp(packet);
            break;
        case IPPROTO_ICMP:
            NSLog(@"Found ICMP packet from: %@  to:  %@",from,to);
            decodeICMP(packet);
            break;
        default:
            NSLog(@"Found Unknown packet from: %@  to:  %@",from,to);
            break;
    }
}

void got_packet(u_char *args, const struct pcap_pkthdr *header,
                const u_char *packet) {
    
    if (packet != NULL) {
        const struct pcap_ethernet *ethernet = (struct pcap_ethernet *)packet;
        NSString *sMac = [NSString stringWithFormat:@"%02X:%02X:%02X:%02X:%02X:%02X",ethernet->ether_shost[0],ethernet->ether_shost[1],ethernet->ether_shost[2],ethernet->ether_shost[3],ethernet->ether_shost[4],ethernet->ether_shost[5]];
        NSString *dMac = [NSString stringWithFormat:@"%02X:%02X:%02X:%02X:%02X:%02X",ethernet->ether_dhost[0],ethernet->ether_dhost[1],ethernet->ether_dhost[2],ethernet->ether_dhost[3],ethernet->ether_dhost[4],ethernet->ether_dhost[5]];
        
         NSLog(@"Source MAC:  %@", sMac);
         NSLog(@"Destin MAC:  %@", dMac);
        
        switch (ntohs(ethernet->ether_type)) {
            case ETHERTYPE_IP:
            NSLog(@"IP:  %d", ethernet->ether_type);
                decodeIp(packet);
                break;
            case ETHERTYPE_ARP:
                NSLog(@"ARP:  %d", ethernet->ether_type);
                decodeArp(packet);
                break;
            default:
                break;
        }
    }
}


int main(int argc, const char * argv[])
{
    
    @autoreleasepool {
        
        // insert code here...
        NSLog(@"Hello, World!");
        pcap_t *handle;
		char errbuf[PCAP_ERRBUF_SIZE];
        bpf_u_int32 localNet, netMask;
        struct bpf_program filterCode;
        char filter[] = "arp or tcp or udp or icmp";
        
        char *dev = pcap_lookupdev(errbuf);
        if (dev==NULL) {
            NSLog(@"Error finding default device %s", errbuf);
            exit(2);
        }
        
        handle = pcap_open_live(dev, SNAPLEN, PROMISC, TIMEOUT, errbuf);
        if (handle == NULL) {
            NSLog(@"Can not open device %s", errbuf);
            exit(2);
        }
        
        if (pcap_lookupnet(dev, &localNet, &netMask, errbuf) == -1) {
            pcap_close(handle);
            NSLog(@"pcap_lookupnet failed");
            exit(2);
        }

        
        if (pcap_compile(handle, &filterCode, filter, 1, netMask) == -1) {
            pcap_close(handle);
            NSLog(@"pcap_compile failed");
            exit(2);
        }
        
        if (pcap_setfilter(handle, &filterCode) == -1) {
			pcap_close(handle);
            NSLog(@"Can't install filter");
            exit(2);
		}
        
        pcap_loop(handle, -1, got_packet,NULL);
        
        pcap_freecode(&filterCode);
        pcap_close(handle);
    }
    return 0;
}

