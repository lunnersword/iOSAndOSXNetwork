//
//  NetworkDevice.m
//  LibpcpaTest1
//
//  Created by System Administrator on 8/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "NetworkDevice.h"

@implementation NetworkDevice
@synthesize name, addresses, network, netmask;

- (id)init
{
    self = [super init];
    if (self) {
        addresses = [[NSMutableArray alloc] init];
    }
    
    return self;
}

-(NSString *)getInetAddress {
    for (NetworkAddress *na in addresses) {
        if ([na.addressType compare:@"INET"] == 0) 
            return na.address;
    }
    return @"";
}
-(NSString *)getInet6Address {
    for (NetworkAddress *na in addresses) {
        if ([na.addressType compare:@"INET6"] == 0)
            return na.address;
    }
    return @"";
}


@end
