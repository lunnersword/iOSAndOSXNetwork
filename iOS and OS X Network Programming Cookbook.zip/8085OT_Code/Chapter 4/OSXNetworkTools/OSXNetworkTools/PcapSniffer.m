//
//  PcapSniffer.m
//  OSXNetworkTools
//
//  Created by System Administrator on 8/4/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "PcapSniffer.h"
#import <sys/types.h>
#import <netinet/in.h>
#import <string.h>
#import <signal.h>
#import <arpa/inet.h>
#import "PCAP_Headers.h"

@implementation PcapSniffer

- (id)init
{
    self = [super init];
    if (self) {
        device = NULL;
        filter = FILTER;
        vp = malloc(sizeof(struct pcap_pack));
    }
    
    return self;
}

-(int)initPcapDevice:(NSString *)dev andFilter:(NSString *)fil {
    
    bpf_u_int32 localNet, netMask;
    struct bpf_program filterCode;
    
    vp->p = pcap_open_live([dev UTF8String], SNAPLEN, PROMISC, TIMEOUT, errbuf);
    if (vp->p == NULL)
        return -1;
    
    int ret = pcap_lookupnet([dev UTF8String], &localNet, &netMask, errbuf);
    if (ret == -1) {
        [self sniffStop];
        NSLog(@"pcap_lookupnet failed");
        return -1;
    }
    
    if (fil != nil)
        filter = [fil UTF8String];
    
    ret = pcap_compile(vp->p, &filterCode, filter, 1, netMask);
    if (ret == -1) {
        [self sniffStop];
        NSLog(@"pcap_compile failed");
        return -1;
    }
    
    ret = pcap_setfilter(vp->p, &filterCode);
    if (ret == -1) {
        [self sniffStop];
        NSLog(@"pcap_setfiler failed");
        return -1;
    }
    
    if (pcap_datalink(vp->p) != DLT_EN10MB)
    {
        [self sniffStop];
        NSLog(@"Requires Ethernet");
        return -1;
    }
    return 1;
}

-(NSDictionary *)sniff {
    
    vp->packet = (u_char *)pcap_next(vp->p, &vp->h);
    if (vp->packet != NULL) {
        
        [self getPacketInfo];
        NSLog(@"Type %@",[packetInfo objectForKey:@"Type"]);
        return packetInfo;
    } else
        return nil;
}

-(void)getPacketInfo {
    packetInfo = [[NSMutableDictionary alloc]init];

    const struct pcap_ethernet *ethernet = (struct pcap_ethernet *)vp->packet;
    switch (ntohs(ethernet->ether_type)) {
        case ETHERTYPE_IP:
            [self decodeIpPacket:vp->packet];
            break;
        case ETHERTYPE_ARP:
            [self decodeArpPacket:vp->packet];
            break;
        default:
            break;
    }
    
}


-(void)decodeIpPacket:(const u_char *)packet {
    const struct pcap_ip *ip = (struct pcap_ip *)(packet + ETHERNET_SIZE);
    
    [packetInfo setValue:@"IP" forKey:@"Type"];
    [packetInfo setValue:[NSString stringWithFormat:@"%s",inet_ntoa(ip->ip_src)] forKey:@"IP From"];
    [packetInfo setValue:[NSString stringWithFormat:@"%s",inet_ntoa(ip->ip_dst)] forKey:@"IP To"];
    [packetInfo setValue:[NSString stringWithFormat:@"%lu",sizeof(packet)] forKey:@"Length"];
    [packetInfo setValue:[NSString stringWithFormat:@"%d",ip->ip_id] forKey:@"ID"];

    
    switch (ip->ip_p) {
        case IPPROTO_TCP:
            [self decode_tcp:packet];
            break;
        case IPPROTO_UDP:
            [self decode_udp:packet];
            break;
        case IPPROTO_ICMP:
            [self decode_icmp:packet];
            break;
        default:
            [self decode_unknown:packet];
            break;
    }
}

-(void)decodeArpPacket:(u_char *)packet {
    const struct pcap_arp *arp = (struct pcap_arp *)(packet + ETHERNET_SIZE);
    switch (ntohs(arp->arp_type)) {
        case ARP_REQUEST:
            [packetInfo setValue:@"ARP Request" forKey:@"Type"];
            [packetInfo setValue:[NSString stringWithFormat:@"%d.%d.%d.%d",arp->arp_spa[0],arp->arp_spa[1],arp->arp_spa[2],arp->arp_spa[3]] forKey:@"IP From"];
            [packetInfo setValue:[NSString stringWithFormat:@"%d.%d.%d.%d",arp->arp_dpa[0],arp->arp_dpa[1],arp->arp_dpa[2],arp->arp_dpa[3]] forKey:@"IP To"];
            break;
            
        case ARP_REPLY:
            [packetInfo setValue:@"ARP Response" forKey:@"Type"];
            [packetInfo setValue:[NSString stringWithFormat:@"%02X:%02X:%02X:%02X:%02X:%02X",arp->arp_sha[0],arp->arp_sha[1],arp->arp_sha[2],arp->arp_sha[3],arp->arp_sha[4],arp->arp_sha[5]] forKey:@"IP From"];
            [packetInfo setValue:[NSString stringWithFormat:@"%d.%d.%d.%d",arp->arp_dpa[0],arp->arp_dpa[1],arp->arp_dpa[2],arp->arp_dpa[3]] forKey:@"IP To"];
            break;
            
        default:
            NSLog(@"%d",arp->arp_type);
            [packetInfo setValue:@"Unknown1" forKey:@"Type"];
            break;
    }

}

-(void)decodeUnknownPacket:(u_char *)packet {
    [packetInfo setValue:@"Unknown2" forKey:@"Type"];
}


-(void)decode_tcp:(const u_char *)packet{
    struct pcap_ip *ip = (struct pcap_ip *)(packet + ETHERNET_SIZE);
    int offset = GET_IP_HEADER_LENGTH(ip)*4;
    struct pcap_tcp *tcp = (struct pcap_tcp *)(packet + ETHERNET_SIZE + offset);
    [packetInfo setValue:@"TCP" forKey:@"Type"];
    [packetInfo setValue:[NSString stringWithFormat:@"%d",ntohs(tcp->tcp_sport)] forKey:@"Port From"];
    [packetInfo setValue:[NSString stringWithFormat:@"%d",ntohs(tcp->tcp_dport)] forKey:@"Port To"];
    [packetInfo setValue:[NSString stringWithFormat:@"%s%s%s%s%s%s",(tcp->tcp_flags & TCP_FIN) ? "F" : "", /* FIN */
                          (tcp->tcp_flags & TCP_SYN) ? "S" : "", /* SYN */
                          (tcp->tcp_flags & TCP_RST) ? "R" : "", /* RST */
                          (tcp->tcp_flags & TCP_PUSH) ? "P" : "", /* PSH */
                          (tcp->tcp_flags & TCP_ACK) ? "A" : "", /* ACK */
                          (tcp->tcp_flags & TCP_URG) ? "U" : ""] /* URG */ forKey:@"Flags"];
    
}
-(void)decode_udp:(const u_char *)packet{
    struct pcap_ip *ip = (struct pcap_ip *)(packet + ETHERNET_SIZE);
    int offset = GET_IP_HEADER_LENGTH(ip)*4;
    struct pcap_udp *udp = (struct pcap_udp *)(packet + ETHERNET_SIZE + offset);
    [packetInfo setValue:@"UDP" forKey:@"Type"];
    [packetInfo setValue:[NSString stringWithFormat:@"%d",ntohs(udp->udp_sport)] forKey:@"Port From"];
    [packetInfo setValue:[NSString stringWithFormat:@"%d",ntohs(udp->udp_dport)] forKey:@"Port To"];
}
-(void)decode_icmp:(const u_char *)packet{
    struct pcap_ip *ip = (struct pcap_ip *)(packet + ETHERNET_SIZE);
    int offset = GET_IP_HEADER_LENGTH(ip)*4;
    struct pcap_icmp *icmp = (struct pcap_icmp *)(packet + ETHERNET_SIZE + offset);
    
    NSString *typeStr = @"ICMP Unknown";
    int iType = icmp->icmp_type;
    switch (iType) {
        case ICMP_ECHO_REPLY_TYPE:
            typeStr=@"ICMP Reply";
            break;
        case ICMP_ECHO_REQUEST_TYPE:
            typeStr=@"ICMP Request";
            break;
        case ICMP_REDIRECT_TYPE:
            typeStr=@"ICMP Redirect";
            break;
        case ICMP_DESTINATION_UNREACHABLE_TYPE:
            typeStr=@"ICMP Unreachable";
            break;
        case ICMP_TRACEROUTE_TYPE:
            typeStr=@"ICMP Traceroute";
            break;
        case ICMP_TIME_EXCEEDED_TYPE:
            typeStr=@"ICMP Time Exceeded";
            break;
            
        default:
            break;
    }
    [packetInfo setValue:typeStr forKey:@"Type"];
    
}
-(void)decode_unknown:(const u_char *)packet{
    [packetInfo setValue:@"Unknown3" forKey:@"Type"];
}


-(void)sniffStop {
    if (vp) {
        if(vp->p) {
            pcap_close(vp->p);
        }
    }
}


@end
