//
//  NetworkAddress.h
//  OSXNetworkTools
//
//  Created by System Administrator on 8/3/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NetworkAddress : NSObject {
    NSString *address, *addressType;
}

@property (strong, nonatomic) NSString *address, *addressType;

@end
