//
//  OSXNetworkToolsAppDelegate.m
//  OSXNetworkTools
//
//  Created by System Administrator on 8/3/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "OSXNetworkToolsAppDelegate.h"

@implementation OSXNetworkToolsAppDelegate

@synthesize window;

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    // Insert code here to initialize your application
    lf = [[LibpcapFunctions alloc]init];
   
    [lf getAllDevs];
    cont = NO;
    tableViewData = [[NSMutableArray alloc]init];

}

- (NSInteger)numberOfItemsInComboBox:(NSComboBox *)aComboBox{
    return [lf.allDevsArray count];
}
- (id)comboBox:(NSComboBox *)aComboBox objectValueForItemAtIndex:(NSInteger)index{
    NetworkDevice *nd = [lf.allDevsArray objectAtIndex:index];
    return nd.name;
}

- (void)comboBoxSelectionDidChange:(NSNotification *)notification {

    NetworkDevice *nd = [lf.allDevsArray objectAtIndex:interfaceSelector.indexOfSelectedItem];
    NSLog(@"changed to:  %@", nd.name);
    if ([nd.addresses count] > 0) {
        [ipAddressLabel setStringValue:[nd getInetAddress]];
        [netmaskLabel setStringValue:nd.netmask];
        [networkLabel setStringValue:nd.network];
    }
    cont = YES;
    [NSThread detachNewThreadSelector:@selector(getPacket:) toTarget:self withObject:nd.name];
 //   [self getPacket];
    
    
  }

-(void)getPacket:(NSString *)dev {
    PcapSniffer *sniffer = [[PcapSniffer alloc]init];
    NSLog(@"Device to capture:  %@", dev);
    [sniffer initPcapDevice:dev andFilter:nil];
    while(cont) {
        NSDictionary *dict = [sniffer sniff];

        if (dict != nil) {
            [self performSelectorOnMainThread:@selector(updateTextViewWith:) withObject:dict waitUntilDone:NO];
        }
    }
}

-(void)updateTextViewWith:(NSDictionary *)str {
    [tableViewData addObject:str];
    [tableView reloadData];
    
}

- (NSInteger)numberOfRowsInTableView:(NSTableView *)tableView {
	return [tableViewData count];
}
- (id)tableView:(NSTableView *)tableView objectValueForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row {
	if (row != -1)
		return [[tableViewData objectAtIndex:row] objectForKey:[tableColumn identifier]];
    
	return nil;
}

-(IBAction)stopButtonPressed:(id)sender {
    cont = NO;
}

@end
