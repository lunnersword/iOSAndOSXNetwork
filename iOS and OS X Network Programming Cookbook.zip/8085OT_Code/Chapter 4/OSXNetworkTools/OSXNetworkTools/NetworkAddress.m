//
//  NetworkAddress.m
//  OSXNetworkTools
//
//  Created by System Administrator on 8/3/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "NetworkAddress.h"

@implementation NetworkAddress
@synthesize address, addressType;
- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
    }
    
    return self;
}


@end
