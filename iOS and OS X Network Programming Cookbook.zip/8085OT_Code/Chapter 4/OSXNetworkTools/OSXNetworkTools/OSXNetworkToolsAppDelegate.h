//
//  OSXNetworkToolsAppDelegate.h
//  OSXNetworkTools
//
//  Created by System Administrator on 8/3/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "LibpcapFunctions.h"
#import "NetworkDevice.h"
#import "PcapSniffer.h"
#include <pcap.h> /* if this gives you an error try pcap/pcap.h */
#include <errno.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netinet/if_ether.h>

@interface OSXNetworkToolsAppDelegate : NSObject <NSApplicationDelegate, NSComboBoxDelegate, NSComboBoxDataSource, NSTableViewDelegate, NSTableViewDataSource> {
    NSWindow *__weak window;
    IBOutlet NSComboBox *interfaceSelector;
    IBOutlet NSTextField *ipAddressLabel, *netmaskLabel, *networkLabel;
    IBOutlet NSTableView *tableView;
    
    NSMutableArray *tableViewData;
    LibpcapFunctions *lf;
    BOOL cont;

}

@property (weak) IBOutlet NSWindow *window;

-(void)updateTextViewWith:(NSDictionary *)str;
-(void)getPacket:(NSString *)dev;

-(IBAction)stopButtonPressed:(id)sender;

@end
