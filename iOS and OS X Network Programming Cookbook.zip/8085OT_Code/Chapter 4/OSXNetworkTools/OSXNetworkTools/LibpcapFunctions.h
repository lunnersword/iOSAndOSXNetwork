//
//  LibpcapFunctions.h
//  LibpcpaTest1
//
//  Created by Jon Hoffman on 8/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NetworkDevice.h"
#import "NetworkAddress.h"
#import <pcap.h>

@interface LibpcapFunctions : NSObject {
    char *dev;
    NSString *devString;
    
    pcap_if_t *allDevs;
    NSMutableArray *allDevsArray;
}

@property (strong, nonatomic) NSString *devString;
@property (strong, nonatomic) NSMutableArray *allDevsArray;

-(int)setDev;
-(int)getAllDevs;


@end
