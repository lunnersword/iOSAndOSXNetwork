//
//  NetworkDevice.h
//  LibpcpaTest1
//
//  Created by System Administrator on 8/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NetworkAddress.h"

@interface NetworkDevice : NSObject {
    NSString *name,  *network, *netmask;
    NSMutableArray *addresses;
}

-(NSString *)getInetAddress;
-(NSString *)getInet6Address;

@property (strong, nonatomic) NSString *name, *network, *netmask;
@property (strong, nonatomic) NSMutableArray *addresses;

@end
