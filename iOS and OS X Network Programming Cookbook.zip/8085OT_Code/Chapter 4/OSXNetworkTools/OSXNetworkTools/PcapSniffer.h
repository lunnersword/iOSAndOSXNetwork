//
//  PcapSniffer.h
//  OSXNetworkTools
//
//  Created by System Administrator on 8/4/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <pcap.h>

#define SNAPLEN         65535  
#define PROMISC         1
#define TIMEOUT         500
#define FILTER          "tcp or udp or icmp"

struct pcap_pack
{
    pcap_t *p;                      
    struct pcap_pkthdr h;                    
    u_char *packet;                 
};



@interface PcapSniffer : NSObject {
    char *device, *filter;
    struct pcap_pack *vp;
    char errbuf[PCAP_ERRBUF_SIZE];
    
    NSArray *icmpType;
    NSMutableDictionary *packetInfo;
  
}


-(int)initPcapDevice:(NSString *)dev andFilter:(NSString *)fil;
-(void)sniffStop;
-(NSDictionary *)sniff;
-(void)getPacketInfo;


-(void)decodeIpPacket:(const u_char *)packet;
-(void)decodeArpPacket:(u_char *)packet;
-(void)decodeUnknownPacket:(u_char *)packet;

-(void)decode_tcp:(const u_char *)packet;
-(void)decode_udp:(const u_char *)packet;
-(void)decode_icmp:(const u_char *)packet;
-(void)decode_unknown:(const u_char *)packet;

@end
