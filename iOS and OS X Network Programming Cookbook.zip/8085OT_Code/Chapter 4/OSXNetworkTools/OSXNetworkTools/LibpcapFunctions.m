//
//  LibpcapFunctions.m
//  LibpcpaTest1
//
//  Created by Jon Hoffman on 8/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "LibpcapFunctions.h"
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

@implementation LibpcapFunctions
@synthesize devString, allDevsArray;

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
    }
    
    return self;
}

-(int)setDev {
    char errbuf[PCAP_ERRBUF_SIZE];
    dev = pcap_lookupdev(errbuf);
    if (dev == NULL) {
        NSLog(@"Error:  %s", errbuf);
        [self setDevString:@""];
        return -1;
    }
    NSLog(@"Dev:  %s", dev);
    [self setDevString:[NSString stringWithCString:dev encoding:NSUTF8StringEncoding]];
    return 1;
}

-(int)getAllDevs {
    bpf_u_int32 netp, maskp;
    char errbuf[PCAP_ERRBUF_SIZE];
    struct in_addr addrNet, addrMask;
    
    allDevsArray = [[NSMutableArray alloc]init];
    if (pcap_findalldevs(&allDevs, errbuf) == -1) {
        NSLog(@"Error:  %s", errbuf);
        return -1;
    }
    
    for(pcap_if_t *d=allDevs; d; d=d->next)
    {
        NSLog(@"Found devs");
        NetworkDevice *nd = [[NetworkDevice alloc]init];
        nd.name = [NSString stringWithCString:d->name encoding:NSUTF8StringEncoding];
        NSLog(@"name:  %@",nd.name);
        //       [allDevsArray addObject:[NSString stringWithCString:d->name encoding:NSUTF8StringEncoding]];
        char s[INET6_ADDRSTRLEN];
        pcap_addr_t *adrs = d->addresses;
        
        for(;adrs;adrs = adrs->next) {
            NSLog(@"Found Address");
            NetworkAddress *na = [[NetworkAddress alloc]init];
            struct sockaddr *sa = adrs->addr;
            switch (sa->sa_family) {
                case AF_INET:
                    inet_ntop(AF_INET, &(((struct sockaddr_in *)sa)->sin_addr),
                              s, sizeof(s));

                    na.addressType = @"INET";
                    na.address = [NSString stringWithCString:s encoding:NSUTF8StringEncoding];
                    [nd.addresses addObject:na];
                    break;
                    
                case AF_INET6:
                    inet_ntop(AF_INET6, &(((struct sockaddr_in6 *)sa)->sin6_addr),
                              s, sizeof(s));
                    na.addressType = @"INET6";
                    na.address = [NSString stringWithCString:s encoding:NSUTF8StringEncoding];
                    [nd.addresses addObject:na];
                    break;
                    
                default:
                    break;
                    
                    
            }
        }
        
        if ([nd.addresses count] > 0) {
            
            pcap_lookupnet(d->name,&netp, &maskp,errbuf);
            addrNet.s_addr = netp;
            addrMask.s_addr = maskp;
            
            nd.network = [NSString stringWithCString:inet_ntoa(addrNet) encoding:NSUTF8StringEncoding];
            nd.netmask = [NSString stringWithCString:inet_ntoa(addrMask) encoding:NSUTF8StringEncoding];
        } else {
 //           [nd.addresses addObject:@"None"];
            nd.netmask = @"";
            nd.network = @"";
        }
        [allDevsArray addObject:nd];
        
    }
    return 0;
}
-(void)dealloc {
    
    pcap_freealldevs(allDevs);
}



@end
