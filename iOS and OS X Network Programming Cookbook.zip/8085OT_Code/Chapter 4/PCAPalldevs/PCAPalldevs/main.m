//
//  main.m
//  PCAPalldevs
//
//  Created by Jon Hoffman on 7/13/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <pcap.h>
#import "NetworkDevice.h"
#import "NetworkAddress.h"
#include <arpa/inet.h>

int main(int argc, const char * argv[])
{
    @autoreleasepool {
 /*       NSLog(@"Hello, World!");
        NSMutableArray *allDevsArray = [[NSMutableArray alloc] init];
        pcap_if_t *allDevs;
        bpf_u_int32 netp, maskp;
        char errbuf[PCAP_ERRBUF_SIZE];
        struct in_addr addrNet, addrMask;
        
        if (pcap_findalldevs(&allDevs, errbuf) == -1) {
            NSLog(@"Error:  %s", errbuf);
            return -1;
        }
        
        for(pcap_if_t *dev=allDevs; dev; dev=dev->next)
        {
            NetworkDevice *nd = [[NetworkDevice alloc]init];
            nd.name = [NSString stringWithCString:dev->name encoding:NSUTF8StringEncoding];
            char addr[INET6_ADDRSTRLEN];
            pcap_addr_t *adrs = dev->addresses;
            for(;adrs;adrs = adrs->next) {
                struct sockaddr *sa = adrs->addr;
                NetworkAddress *na = [[NetworkAddress alloc] init];
                switch (sa->sa_family) {
                    case AF_INET:
                        inet_ntop(AF_INET, &(((struct sockaddr_in *)sa)->sin_addr),
                                  addr, sizeof(addr));
                        na.addressType = @"INET";
                        na.address = [NSString stringWithCString:addr encoding:NSUTF8StringEncoding];
                        [nd.addresses addObject:na];
                        break;
                        
                    case AF_INET6:
                        inet_ntop(AF_INET6, &(((struct sockaddr_in6 *)sa)->sin6_addr),
                                  addr, sizeof(addr));
                        na.addressType = @"INET6";
                        na.address = [NSString stringWithCString:addr encoding:NSUTF8StringEncoding];
                        [nd.addresses addObject:na];
                        break;
                        
                    default:
                        break;
                }
            }
            if ([nd.addresses count] > 0) {  
                pcap_lookupnet(dev->name,&netp, &maskp,errbuf);
                addrNet.s_addr = netp;
                addrMask.s_addr = maskp;
                nd.network = [NSString stringWithCString:inet_ntoa(addrNet) encoding:NSUTF8StringEncoding];
                nd.netmask = [NSString stringWithCString:inet_ntoa(addrMask) encoding:NSUTF8StringEncoding];
            } else {
                nd.netmask = @"";
                nd.network = @"";
            }
            [allDevsArray addObject:nd];
        }
        pcap_freealldevs(allDevs);
        for(NetworkDevice *dev in allDevsArray) {
            NSLog(@"Found Device:  %@", dev.name);
            NSLog(@"   Network:  %@", dev.network);
            NSLog(@"   Netmask:  %@", dev.netmask);
            for (NetworkAddress *addr in dev.addresses)
                NSLog(@"     %@:  %@", addr.addressType, addr.address);
        } 
            */
        
        NSLog(@"Hello, World!");
        pcap_if_t *allDevs;
        char errbuf[PCAP_ERRBUF_SIZE];
        
        if (pcap_findalldevs(&allDevs, errbuf) == -1) {
            NSLog(@"Error:  %s", errbuf);
            return -1;
        }
        
        for(pcap_if_t *dev=allDevs; dev; dev=dev->next)
        {
            NSLog(@"\n");
            NSLog(@"%s", dev->name);
            NSLog(@"-----------------------");
            char addr[INET6_ADDRSTRLEN];
            memset(&addr[0], 0, sizeof(addr));
            pcap_addr_t *adrs = dev->addresses;
            for(;adrs;adrs = adrs->next) {
                struct sockaddr *sa = adrs->addr;
                inet_ntop(sa->sa_family, &(((struct sockaddr_in *)sa)->sin_addr),
                          addr, sizeof(addr));
                NSLog(@"    %s", addr);
            }
        }
        
        
        
    }
    return 0;
}

