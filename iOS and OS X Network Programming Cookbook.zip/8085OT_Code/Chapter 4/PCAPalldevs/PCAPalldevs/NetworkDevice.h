//
//  NetworkDevice.h
//  LibpcpaTest1
//
//  Created by System Administrator on 8/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NetworkAddress.h"

@interface NetworkDevice : NSObject 

@property (retain, nonatomic) NSString *name, *network, *netmask;
@property (retain, nonatomic) NSMutableArray *addresses;

@end
