//
//  NetworkAddress.m
//  OSXNetworkTools
//
//  Created by System Administrator on 8/3/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "NetworkAddress.h"

@implementation NetworkAddress
@synthesize address, addressType;


@end
