//
//  main.m
//  PortScanner
//
//  Created by Jon Hoffman on 7/28/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <libnet.h>
#import <pcap.h>
#import "PCAP_Headers.h"

#define SNAPLEN 65535
#define PROMISC 1
#define TIMEOUT 500



void got_packet(u_char *args, const struct pcap_pkthdr *header,
                const u_char *packet) {
    
    if (packet != NULL) {
        struct pcap_ip *ip = (struct pcap_ip *)(packet + ETHERNET_SIZE);
        int offset = GET_IP_HEADER_LENGTH(ip)*4;
        struct pcap_tcp *tcp = (struct pcap_tcp *)(packet + ETHERNET_SIZE + offset);
        
        int from =ntohs(tcp->tcp_sport);
        
        if (tcp->tcp_flags & TCP_RST) {
            NSLog(@"Port %d: Closed", from);
        } else if (tcp->tcp_flags & TCP_SYN) {
            NSLog(@"Port %d:  Open", from);
        } else {
            NSLog(@"Port %d:  Unknown", from);
        }
    }
}

int main(int argc, const char * argv[])
{
    
    @autoreleasepool {
        NSLog(@"Hello, World!");
        libnet_t *lnet;
        pcap_t *pcap;
		char errbuf[PCAP_ERRBUF_SIZE];
        bpf_u_int32 localNet, netMask;
        u_int32_t source, target;
        struct bpf_program filterCode;
        struct pcap_pkthdr header;
		const u_char *packet;
        libnet_ptag_t tcp = 0, ipv4 = 0;
        int reply = 0;
        char *TARGETIP = "10.0.0.16";
        char filter[] = "src host 10.0.0.16 && tcp";
        
        //Libnet Setup
        lnet = libnet_init(LIBNET_RAW4, NULL, errbuf);
        if ( lnet == NULL ) {
            NSLog(@"Error with libnet_init():  %s", errbuf);
            exit(EXIT_FAILURE);
        }
        
        target = libnet_name2addr4(lnet, TARGETIP, LIBNET_DONT_RESOLVE);
        source = libnet_get_ipaddr4(lnet);
        if ( source == -1 ) {
            NSLog(@"Error retrieving IP address: %s",libnet_geterror(lnet));
            libnet_destroy(lnet);
            exit(EXIT_FAILURE);
        }
        
        libnet_seed_prand (lnet);
        
        //PCAP Setup
        char *dev = pcap_lookupdev(errbuf);
        if (dev==NULL) {
            NSLog(@"Error finding default device %s", errbuf);
            exit(2);
        }
        
        pcap= pcap_open_live(dev, SNAPLEN, PROMISC, TIMEOUT, errbuf);
        if (pcap == NULL) {
            NSLog(@"Can not open device %s", errbuf);
            exit(2);
        }
        
        if (pcap_lookupnet(dev, &localNet, &netMask, errbuf) == -1) {
            pcap_close(pcap);
            NSLog(@"pcap_lookupnet failed");
            exit(2);
        }
        
        if (pcap_compile(pcap, &filterCode, filter, 1, netMask) == -1) {
            pcap_close(pcap);
            NSLog(@"pcap_compile failed");
            exit(2);
        }
        
        if (pcap_setfilter(pcap, &filterCode) == -1) {
			pcap_close(pcap);
            NSLog(@"Can't install filter");
            exit(2);
		}
        
        //Looping though ports
        for (int portNum=1; portNum<1024; portNum++) {
            /* Building TCP header */
            if ((tcp = libnet_build_tcp (libnet_get_prand (LIBNET_PRu16),
                                  portNum,
                                  0,
                                  0,
                                  TH_SYN,
                                  1024,
                                  0,
                                  0,
                                  LIBNET_TCP_H,
                                  NULL,
                                  0,
                                  lnet,
                                  tcp)) == -1)
            {
                NSLog(@"Error building TCP header: %s\n",libnet_geterror(lnet));
                libnet_destroy(lnet);
                exit(EXIT_FAILURE);
            }
            
            /* Building IP header */
            if( (ipv4 = libnet_build_ipv4(LIBNET_TCP_H + LIBNET_IPV4_H ,
                                  0,
                                  libnet_get_prand (LIBNET_PRu16),
                                  0,
                                  64,
                                  IPPROTO_TCP,
                                  0,
                                  source,
                                  target,
                                  NULL,
                                  0,
                                  lnet,
                                  ipv4)) == -1)
            {
                NSLog(@"Error building IP header: %s\n",libnet_geterror(lnet));
                libnet_destroy(lnet);
                exit(EXIT_FAILURE);
            }
            
            /* Writing packet */
            int bytes_written = libnet_write(lnet);
            if ( bytes_written == -1 )
                NSLog(@"Error writing packet: %s\n",libnet_geterror(lnet));
            else {
                reply =0;
                while (!reply) {
                    packet = pcap_next(pcap, &header);
                    //Capture timed out
                    if (packet == NULL) {
                        NSLog(@"Port %d:  No Reply (timeout)", portNum);
                        reply =1;
                    } else {
                        struct pcap_ip *ip = (struct pcap_ip *)(packet + ETHERNET_SIZE);
                        int offset = GET_IP_HEADER_LENGTH(ip)*4;
                        struct pcap_tcp *tcp = (struct pcap_tcp *)(packet + ETHERNET_SIZE + offset);
                        
                        int from =ntohs(tcp->tcp_sport);
                        //If port matches the packet we sent out
                        if (from == portNum) {
                            if (tcp->tcp_flags & TCP_RST) {
                                NSLog(@"Port %d: Closed", from);
                            } else if (tcp->tcp_flags & TCP_SYN) {
                                NSLog(@"Port %d:  Open", from);
                            } else {
                                NSLog(@"Port %d:  Unknown", from);
                            }
                            reply = 1;
                        }
                        
                    }
                    
                }
            }
            
        }
        libnet_destroy(lnet);
        pcap_close(pcap);
    }
    return 0;
}

