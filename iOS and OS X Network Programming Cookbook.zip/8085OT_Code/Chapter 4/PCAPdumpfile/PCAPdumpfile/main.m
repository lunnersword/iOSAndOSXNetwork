//
//  main.m
//  PCAPdumpfile
//
//  Created by Jon Hoffman on 7/14/13.
//  Copyright (c) 2013 Jon Hoffman. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <pcap.h>
#import <netinet/in.h>
#import <arpa/inet.h>
#import "PCAP_Headers.h"

#define SNAPLEN 65535
#define PROMISC 1
#define TIMEOUT 500

void dispatcher_handler(u_char *dumpfile, const struct pcap_pkthdr *header, const u_char *pkt_data)
{
    pcap_dump(dumpfile,header,pkt_data);
    
    //view file "tcpdump -qns 0 -A -r /Users/hoffmanjon/pcapdump.pcap"
}


int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        // insert code here...
        NSLog(@"Hello, World!");
        pcap_t *handle;
		char errbuf[PCAP_ERRBUF_SIZE];
        bpf_u_int32 localNet, netMask;
        struct bpf_program filterCode;
        char filter[] = "arp or tcp or udp or icmp";
        pcap_dumper_t *dumpfile;
        
        char *dev = pcap_lookupdev(errbuf);
        if (dev==NULL) {
            NSLog(@"Error finding default device %s", errbuf);
            exit(2);
        }
        
        handle = pcap_open_live(dev, SNAPLEN, PROMISC, TIMEOUT, errbuf);
        if (handle == NULL) {
            NSLog(@"Can not open device %s", errbuf);
            exit(2);
        }
        
        if (pcap_lookupnet(dev, &localNet, &netMask, errbuf) == -1) {
            pcap_close(handle);
            NSLog(@"pcap_lookupnet failed");
            exit(2);
        }
        
        if (pcap_compile(handle, &filterCode, filter, 1, netMask) == -1) {
            pcap_close(handle);
            NSLog(@"pcap_compile failed");
            exit(2);
        }
        
        if (pcap_setfilter(handle, &filterCode) == -1) {
			pcap_close(handle);
            NSLog(@"Can't install filter");
            exit(2);
		}
        
        dumpfile=pcap_dump_open(handle, "/Users/hoffmanjon/pcapdump.pcap");
        if(dumpfile==NULL){
            NSLog(@"Error opening output file");
            exit(2);
        }
        
        pcap_loop(handle, 0, dispatcher_handler, (unsigned char *)dumpfile);

        pcap_dump_close(dumpfile);
        pcap_freecode(&filterCode);
        pcap_close(handle);
    }
    return 0;
}

