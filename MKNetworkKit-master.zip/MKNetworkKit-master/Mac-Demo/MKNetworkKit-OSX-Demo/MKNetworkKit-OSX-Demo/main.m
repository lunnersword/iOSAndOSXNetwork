//
//  main.m
//  MKNetworkKit-OSX-Demo
//
//  Created by Mugunth Kumar on 7/12/11.
//  Copyright (c) 2011 Steinlogic. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, (const char **)argv);
}
